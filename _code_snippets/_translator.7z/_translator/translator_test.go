// + build x
// Copyright 2020 Thomas.Hoehenleitner [at] seerose.net
// Use of this source code is governed by a license that can be found in the LICENSE file.

package translator

import "testing"

func Test0(t *testing.T) {
	// todo (is now implicit tested with emmiter tests)
}

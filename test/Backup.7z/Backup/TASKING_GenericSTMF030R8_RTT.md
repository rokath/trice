# TASKING_GenericSTMF030R8_RTT

- unbuffered RTT
- About: [SeggerRTT.md](SeggerRTT.md)
- It is possible to add text messages as well. Their characters get discarded but appear also on the display.

![TASKING_GenericSTMF030R8_RTT_0.PNG](./README.media/TASKING_GenericSTMF030R8_RTT_0.PNG)
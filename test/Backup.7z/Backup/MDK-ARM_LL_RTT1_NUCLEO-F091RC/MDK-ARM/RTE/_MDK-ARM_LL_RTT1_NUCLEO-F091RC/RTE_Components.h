
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'MDK-ARM_LL_RTT1_NUCLEO-F091RC' 
 * Target:  'MDK-ARM_LL_RTT1_NUCLEO-F091RC' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "stm32f0xx.h"



#endif /* RTE_COMPONENTS_H */

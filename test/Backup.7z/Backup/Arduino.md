# Arduino

- install arduino-cli
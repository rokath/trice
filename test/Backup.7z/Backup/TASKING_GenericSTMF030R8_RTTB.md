# TASKING_GenericSTMF030R8_RTTB
- buffered RTT
- About: [SeggerRTT.md](SeggerRTT.md)
- ~ 22 clocks

  ![TASKING_GenericSTMF030R8_RTTB_0.PNG](./README.media/TASKING_GenericSTMF030R8_RTTB_0.PNG)

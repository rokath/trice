
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'MDK-ARM_LL_UART_demoBoard_STM32F030F4F4P6' 
 * Target:  'MDK-ARM_LL_UART_demoBoard_STM32F030F4F4P6' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "stm32f0xx.h"



#endif /* RTE_COMPONENTS_H */

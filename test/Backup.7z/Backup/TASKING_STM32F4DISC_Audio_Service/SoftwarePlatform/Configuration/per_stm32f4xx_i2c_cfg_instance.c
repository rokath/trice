/*
 *  Software Platform Generated File
 *  --------------------------------
 */

#include "per_stm32f4xx_i2c_cfg_instance.h"

extern void pincfg_i2c1_init(void);


const per_stm32f4xx_i2c_cfg_instance_t per_stm32f4xx_i2c_instance_table[1] = 
{
    {
        0,
            0x40005400,
            pincfg_i2c1_init,
            31,
            32,
    },

};

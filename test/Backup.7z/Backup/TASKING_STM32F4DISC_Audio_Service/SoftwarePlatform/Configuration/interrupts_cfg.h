/*
 *  Software Platform Generated File
 *  --------------------------------
 */

#ifndef _SWP_INTERRUPTS_CFG_H
#define _SWP_INTERRUPTS_CFG_H

#include <stdint.h>


#define INTERRUPTS_APPLICATION_MASK  0x0
#define INTERRUPTS_MAX_HANDLERS  32
#define INTERRUPTS_HASH_SIZE  32

#endif /* _SWP_INTERRUPTS_CFG_H */

/*
 *  Software Platform Generated File
 *  --------------------------------
 */

#ifndef _SWP_PER_STM32F4XX_I2S_CFG_H
#define _SWP_PER_STM32F4XX_I2S_CFG_H


#define PER_STM32F4XX_I2S_INSTANCE_COUNT  1

#define PER_STM32F4XX_I2S_MAXIMUM_NUMBER_INSTANCE_USERS  1

#define PER_STM32F4XX_I2S_INSTANCE_STM32F4XX_I2S3_USED  1



#endif /* _SWP_PER_STM32F4XX_I2S_CFG_H */

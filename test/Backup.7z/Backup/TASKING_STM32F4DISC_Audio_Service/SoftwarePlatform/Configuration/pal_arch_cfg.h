/*
 *  Software Platform Generated File
 *  --------------------------------
 */

#ifndef _SWP_PAL_ARCH_CFG_H
#define _SWP_PAL_ARCH_CFG_H




#endif /* _SWP_PAL_ARCH_CFG_H */

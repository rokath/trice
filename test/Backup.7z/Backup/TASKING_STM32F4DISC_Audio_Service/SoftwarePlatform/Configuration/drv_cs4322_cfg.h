/*
 *  Software Platform Generated File
 *  --------------------------------
 */

#ifndef _SWP_DRV_CS4322_CFG_H
#define _SWP_DRV_CS4322_CFG_H


#define DRV_CS4322_INSTANCE_COUNT  1

#define DRV_CS4322_MAXIMUM_NUMBER_INSTANCE_USERS  1



#endif /* _SWP_DRV_CS4322_CFG_H */

/*
 *  Software Platform Generated File
 *  --------------------------------
 */

#include "audio_cfg_instance.h"

static const int audio_instance0_ad_codec[1] = { 0 };


const audio_cfg_instance_t audio_instance_table[1] = 
{
    {
            22050,
            AUDIO_INSTANCE_CHANNELS_STEREO,
            AUDIO_INSTANCE_SAMPLESIZE_16,
        0,
        { .instances = &audio_instance0_ad_codec[0], .size = 1 },
    },

};

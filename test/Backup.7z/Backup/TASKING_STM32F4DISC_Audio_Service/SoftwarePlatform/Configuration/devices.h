/*
 *  Software Platform Generated File
 *  --------------------------------
 */

#ifndef _SWP_DEVICES_H
#define _SWP_DEVICES_H

/* instance id macros */
#define AUDIO_1  0

#define DRV_CS4322_1  0

#define DRV_STM32_GPIO_1  0
#define STM32F4XX_GPIOD_DRV_STM32_GPIO_ID  DRV_STM32_GPIO_1

#define DRV_STM32_I2CM_1  0
#define STM32F4XX_I2C1_DRV_STM32_I2CM_ID  DRV_STM32_I2CM_1

#define DRV_STM32_I2SM_1  0
#define STM32F4XX_I2S3_DRV_STM32_I2SM_ID  DRV_STM32_I2SM_1

#define STM32F4XX_GPIOD  0

#define STM32F4XX_I2C1  0

#define STM32F4XX_I2S3  0

#endif /* _SWP_DEVICES_H */

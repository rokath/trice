/*
 *  Software Platform Generated File
 *  --------------------------------
 */

#include "ad_cs4322_to_audio_cfg_instance.h"


const ad_cs4322_to_audio_cfg_instance_t ad_cs4322_to_audio_instance_table[1] = 
{
    {
        0,
        0,
    },

};

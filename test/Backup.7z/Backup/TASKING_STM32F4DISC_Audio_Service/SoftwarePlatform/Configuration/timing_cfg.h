/*
 *  Software Platform Generated File
 *  --------------------------------
 */

#ifndef _SWP_TIMING_CFG_H
#define _SWP_TIMING_CFG_H

#include <stdint.h>
#include <stdbool.h>


#define TIMING_CLOCKHZ  84000000
#define TIMING_USETIMERS  0

#endif /* _SWP_TIMING_CFG_H */

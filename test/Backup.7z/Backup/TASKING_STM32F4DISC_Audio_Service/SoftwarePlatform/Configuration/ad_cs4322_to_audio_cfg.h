/*
 *  Software Platform Generated File
 *  --------------------------------
 */

#ifndef _SWP_AD_CS4322_TO_AUDIO_CFG_H
#define _SWP_AD_CS4322_TO_AUDIO_CFG_H


#define AD_CS4322_TO_AUDIO_INSTANCE_COUNT  1

#define AD_CS4322_TO_AUDIO_MAXIMUM_NUMBER_INSTANCE_USERS  1



#endif /* _SWP_AD_CS4322_TO_AUDIO_CFG_H */

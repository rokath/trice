/*
 *  Software Platform Generated File
 *  --------------------------------
 */

#ifndef _SWP_DRV_STM32_GPIO_CFG_H
#define _SWP_DRV_STM32_GPIO_CFG_H


#define DRV_STM32_GPIO_INSTANCE_COUNT  1

#define DRV_STM32_GPIO_MAXIMUM_NUMBER_INSTANCE_USERS  0



#endif /* _SWP_DRV_STM32_GPIO_CFG_H */

/*
 *  Software Platform Generated File
 *  --------------------------------
 */

#include "drv_stm32_gpio_cfg_instance.h"


const drv_stm32_gpio_cfg_instance_t drv_stm32_gpio_instance_table[1] = 
{
    {
            0x0000,
        0,
    },

};

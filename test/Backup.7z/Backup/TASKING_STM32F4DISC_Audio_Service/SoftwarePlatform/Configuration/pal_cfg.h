/*
 *  Software Platform Generated File
 *  --------------------------------
 */

#ifndef _SWP_PAL_CFG_H
#define _SWP_PAL_CFG_H

#include <stdint.h>
#include <stdbool.h>


#define PAL_CLOCKHZ  84000000
#define PAL_USETIMERS  0
#define PAL_INTERRUPT_CONTROL_CFG  0x8000C091

#endif /* _SWP_PAL_CFG_H */

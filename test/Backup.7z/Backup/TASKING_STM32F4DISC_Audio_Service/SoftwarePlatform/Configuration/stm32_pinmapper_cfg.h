/*
 *  Software Platform Generated File
 *  --------------------------------
 */

#ifndef _SWP_STM32_PINMAPPER_CFG_H
#define _SWP_STM32_PINMAPPER_CFG_H




#endif /* _SWP_STM32_PINMAPPER_CFG_H */

/*
 *  Software Platform Generated File
 *  --------------------------------
 */

#include "per_stm32f4xx_gpio_cfg_instance.h"

extern void pincfg_gpiod_init(void);


const per_stm32f4xx_gpio_cfg_instance_t per_stm32f4xx_gpio_instance_table[1] = 
{
    {
        3,
            0x40020C00,
            pincfg_gpiod_init,
    },

};

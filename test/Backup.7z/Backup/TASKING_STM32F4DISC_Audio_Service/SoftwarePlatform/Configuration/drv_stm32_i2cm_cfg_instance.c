/*
 *  Software Platform Generated File
 *  --------------------------------
 */

#include "drv_stm32_i2cm_cfg_instance.h"


const drv_stm32_i2cm_cfg_instance_t drv_stm32_i2cm_instance_table[1] = 
{
    {
            100000,
        0,
    },

};

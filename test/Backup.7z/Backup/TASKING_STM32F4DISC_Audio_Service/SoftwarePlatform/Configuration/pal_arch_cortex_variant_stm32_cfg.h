/*
 *  Software Platform Generated File
 *  --------------------------------
 */

#ifndef _SWP_PAL_ARCH_CORTEX_VARIANT_STM32_CFG_H
#define _SWP_PAL_ARCH_CORTEX_VARIANT_STM32_CFG_H




#endif /* _SWP_PAL_ARCH_CORTEX_VARIANT_STM32_CFG_H */

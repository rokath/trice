/*
 *  Software Platform Generated File
 *  --------------------------------
 */

#ifndef _SWP_DRV_STM32_I2CM_CFG_H
#define _SWP_DRV_STM32_I2CM_CFG_H


#define DRV_STM32_I2CM_INSTANCE_COUNT  1

#define DRV_STM32_I2CM_MAXIMUM_NUMBER_INSTANCE_USERS  1



#endif /* _SWP_DRV_STM32_I2CM_CFG_H */

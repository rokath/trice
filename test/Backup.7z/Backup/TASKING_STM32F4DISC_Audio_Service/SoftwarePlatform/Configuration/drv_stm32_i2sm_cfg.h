/*
 *  Software Platform Generated File
 *  --------------------------------
 */

#ifndef _SWP_DRV_STM32_I2SM_CFG_H
#define _SWP_DRV_STM32_I2SM_CFG_H

#include <drv_stm32_i2sm_internal.h>

#define DRV_STM32_I2SM_INSTANCE_COUNT  1

#define DRV_STM32_I2SM_MAXIMUM_NUMBER_INSTANCE_USERS  1



#endif /* _SWP_DRV_STM32_I2SM_CFG_H */

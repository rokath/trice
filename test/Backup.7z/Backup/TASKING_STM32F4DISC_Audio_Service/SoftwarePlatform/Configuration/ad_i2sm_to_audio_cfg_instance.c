/*
 *  Software Platform Generated File
 *  --------------------------------
 */

#include "ad_i2sm_to_audio_cfg_instance.h"


const ad_i2sm_to_audio_cfg_instance_t ad_i2sm_to_audio_instance_table[1] = 
{
    {
        0,
        0,
    },

};

/*
 *  Software Platform Generated File
 *  --------------------------------
 */

#ifndef _SWP_PER_STM32F4XX_I2C_CFG_H
#define _SWP_PER_STM32F4XX_I2C_CFG_H


#define PER_STM32F4XX_I2C_INSTANCE_COUNT  1

#define PER_STM32F4XX_I2C_MAXIMUM_NUMBER_INSTANCE_USERS  1

#define PER_STM32F4XX_I2C_INSTANCE_STM32F4XX_I2C1_USED  1



#endif /* _SWP_PER_STM32F4XX_I2C_CFG_H */

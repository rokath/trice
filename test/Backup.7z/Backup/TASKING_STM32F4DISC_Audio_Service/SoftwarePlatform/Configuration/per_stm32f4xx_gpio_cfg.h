/*
 *  Software Platform Generated File
 *  --------------------------------
 */

#ifndef _SWP_PER_STM32F4XX_GPIO_CFG_H
#define _SWP_PER_STM32F4XX_GPIO_CFG_H

#include <stm32f4xx_gpio.h>

#define PER_STM32F4XX_GPIO_INSTANCE_COUNT  1

#define PER_STM32F4XX_GPIO_MAXIMUM_NUMBER_INSTANCE_USERS  1

#define PER_STM32F4XX_GPIO_INSTANCE_STM32F4XX_GPIOD_USED  1



#endif /* _SWP_PER_STM32F4XX_GPIO_CFG_H */

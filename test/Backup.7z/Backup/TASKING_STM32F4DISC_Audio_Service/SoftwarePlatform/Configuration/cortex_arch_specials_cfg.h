/*
 *  Software Platform Generated File
 *  --------------------------------
 */

#ifndef _SWP_CORTEX_ARCH_SPECIALS_CFG_H
#define _SWP_CORTEX_ARCH_SPECIALS_CFG_H

#include <stddef.h>


#define CORTEX_ARCH_SPECIALS_INTERRUPT_MASK  "0-239"

#endif /* _SWP_CORTEX_ARCH_SPECIALS_CFG_H */

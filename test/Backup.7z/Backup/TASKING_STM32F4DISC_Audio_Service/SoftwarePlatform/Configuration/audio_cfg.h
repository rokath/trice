/*
 *  Software Platform Generated File
 *  --------------------------------
 */

#ifndef _SWP_AUDIO_CFG_H
#define _SWP_AUDIO_CFG_H

#include <stddef.h>

#define AUDIO_INSTANCE_COUNT  1

#define AUDIO_MAXIMUM_NUMBER_INSTANCE_USERS  0
#define AUDIO_MAX_DOWNLINKS_OVER_AD_CODEC_INTERFACE  1



#endif /* _SWP_AUDIO_CFG_H */

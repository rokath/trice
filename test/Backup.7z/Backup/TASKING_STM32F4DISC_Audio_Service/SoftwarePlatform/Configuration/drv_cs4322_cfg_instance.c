/*
 *  Software Platform Generated File
 *  --------------------------------
 */

#include "drv_cs4322_cfg_instance.h"


const drv_cs4322_cfg_instance_t drv_cs4322_instance_table[1] = 
{
    {
            0x94,
            DRV_CS4322_INSTANCE_I2S_STANDARD_I2S_PHILIPS,
            DRV_CS4322_INSTANCE_I2S_DATAFORMAT_16BIT,
            DRV_CS4322_INSTANCE_I2S_CPOL_LOW,
        0,
    },

};

C++ EXAMPLE, COMPLEX NUMBER CALCULATION

This example contains a small C++ program, that handles complex
number calculation using C++ operator overloading. The program
will give output using FSS (File System Simulation).

--
@(#)readme.txt	1.5

# STM32CubeIDE_RTTD_NUCLEO-G474

- has an on-board ST-LINK v3 -> not reflashable to on-board SEGGER J-LINK
- Firmware should work but needs to be tested with **gostlink**

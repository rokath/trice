# atollic trueSTUDIO examples

- [atollicTrueSTUDIO_RTTD_DISCOVERY-STM32F407VGTx](atollicTrueSTUDIO_RTTD_DISCOVERY-STM32F4.md)
  - ~ 200 clocks
- [atollicTrueSTUDIO_ITM_Printf_DISCOVERY-STM32F407VGTx](atollicTrueSTUDIO_ITM_Printf_DISCOVERY-S.md)
  - only ITM check, no trice instrumentation

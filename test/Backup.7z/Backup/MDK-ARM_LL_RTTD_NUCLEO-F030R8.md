# MDK-ARM_LL_RTTD_NUCLEO-F030R8
- direct RTT
- About: [SeggerRTT.md](SeggerRTT.md)
- ~230 clocks but sync issue after RESET

![MDK-ARM_LL_RTTD_NUCLEO-F030R8_noSync.PNG](./README.media/MDK-ARM_LL_RTTD_NUCLEO-F030R8_noSync.PNG)
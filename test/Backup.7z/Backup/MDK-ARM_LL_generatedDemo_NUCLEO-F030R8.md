# trice Demo Project NUCLEO-F030R8

## MDK-ARM_LL_generatedDemo_NUCLEO-F030R8
- This is *without* TRICE instrumentation and ment for easy comparing to see quickly the intrumentation needs with MDK-ARM_LL_* projects.
- Setup details: [MDK-ARM_LL_generatedDemo_NUCLEO-F030R8]

## Prerequisites (as example)
- ST Microelectronic evaluation board NUCLEO-F030R8 or similar
  - costs about 10 EUR
- ST Microelectronic CubeMX
  - free
- ARMkeil IDE
  - free for small projects, also free license for some STM devices

## Demo Project setup steps (This is STM32 specific and shown here only for absolute beginners)

### CubeMx setup
- New project, select NUCLEO-F030R8 (answer "Yes")

  ![](README.media/CubeMX_1.PNG)
- Enable USART2 interrupt: 

  ![](README.media/CubeMX_2.PNG)
- Select LL instead of HAL for USART: 

  ![](README.media/CubeMX_3.PNG)
- Necessary library files as reference:

  ![](README.media/CubeMX_4.PNG)
- Set project name, location and toolchain: 

  ![](README.media/CubeMX_5.PNG)
- Adjust baudrate of UART2 if you like. In the example project 115200 is used.
- Generate Code and open project: 
  
  ![](README.media/CubeMX_6.PNG)

- This is all about the generatedDemo, it is just the CubeMX project setup.
- What follows are the steps to instrument the code with trice to get the MDK-ARM_LL_UART_NUCLEO-F030R8 project.

## ARMkeil IDE setup
### Project settings
  - Add `trice.c` and acompanying files to the project.
  - Extend include path with trice folder.
  - Edit project settings: 
  
    ![](README.media/ARMkeil_8.PNG)
    
### File compare
- `generatedDemoF030R8` - fresh empty STM32 CubMX project after CubeMX setup
- `triceDemoF030R8` - the `generatedDemoF030R8` equipped with trice
- Directories

  ![](README.media/F030R8DirCompare.PNG)

  [triceConfig.h](../examples/triceDemoF030R8/Inc/triceConfig.h)

  [triceCheck.h](../examples/triceDemoF030R8/Inc/triceCheck.h)
  [triceCheck.c](../examples/triceDemoF030R8/Src/triceCheck.c)

  [til.json](../examples/triceDemoF030R8/MDK-ARM/til.json)

- Changes in main.c

  ![](README.media/F030R8MainCompare.PNG)

- Changes in stm32f0xx_it.c

  ![](README.media/F030R8InterruptsCompare.PNG)

- Compile and flash

### Run

- Connect evaluation board over USB with PC and detect the virtual COM port `trice log -port COMscan`
- Execute `trice log -port COM12 -baud 115200`, when COM12 is your interface port
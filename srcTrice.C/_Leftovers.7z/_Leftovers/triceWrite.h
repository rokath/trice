/*! \file triceWrite.h
\author thomas.hoehenleitner [at] seerose.net
*******************************************************************************/

unsigned triceWriteSpace( void );
unsigned triceWrite(const void *buf, int nbytes);
void triceServe( void ); // wrap
void triceServeBare( void ); // bare


// Copyright 2020 Thomas.Hoehenleitner [at] seerose.net

// Package args implements the command-line interface and calls the appropriate commands.
package stimargs

-- The C compiler identification is GNU 15.2.0
-- Detecting C compiler ABI info
-- Detecting C compiler ABI info - done
-- Check for working C compiler: /usr/local/bin/gcc - skipped
-- Detecting C compile features
-- Detecting C compile features - done
-- Configuring done (0.2s)
-- Generating done (0.0s)
-- Build files have been written to: /home/th/repos/trice/examples/DemoData_Trice/build
[  4%] Building C object CMakeFiles/DemoData_Trice.dir/src/main.c.o
[  8%] Building C object CMakeFiles/DemoData_Trice.dir/home/th/repos/trice/src/SEGGER_RTT.c.o
[ 12%] Building C object CMakeFiles/DemoData_Trice.dir/home/th/repos/trice/src/cobsDecode.c.o
[ 16%] Building C object CMakeFiles/DemoData_Trice.dir/home/th/repos/trice/src/cobsEncode.c.o
[ 20%] Building C object CMakeFiles/DemoData_Trice.dir/home/th/repos/trice/src/tcobsv1Decode.c.o
[ 25%] Building C object CMakeFiles/DemoData_Trice.dir/home/th/repos/trice/src/tcobsv1Encode.c.o
[ 29%] Building C object CMakeFiles/DemoData_Trice.dir/home/th/repos/trice/src/trice.c.o
[ 33%] Building C object CMakeFiles/DemoData_Trice.dir/home/th/repos/trice/src/trice16.c.o
[ 37%] Building C object CMakeFiles/DemoData_Trice.dir/home/th/repos/trice/src/trice32.c.o
[ 41%] Building C object CMakeFiles/DemoData_Trice.dir/home/th/repos/trice/src/trice64.c.o
[ 45%] Building C object CMakeFiles/DemoData_Trice.dir/home/th/repos/trice/src/trice8.c.o
[ 50%] Building C object CMakeFiles/DemoData_Trice.dir/home/th/repos/trice/src/triceAuxiliary.c.o
[ 54%] Building C object CMakeFiles/DemoData_Trice.dir/home/th/repos/trice/src/triceDoubleBuffer.c.o
[ 58%] Building C object CMakeFiles/DemoData_Trice.dir/home/th/repos/trice/src/triceLog.c.o
[ 62%] Building C object CMakeFiles/DemoData_Trice.dir/home/th/repos/trice/src/triceLogAnsi.c.o
[ 66%] Building C object CMakeFiles/DemoData_Trice.dir/home/th/repos/trice/src/triceLogMinimal.c.o
[ 70%] Building C object CMakeFiles/DemoData_Trice.dir/home/th/repos/trice/src/triceRingBuffer.c.o
[ 75%] Building C object CMakeFiles/DemoData_Trice.dir/home/th/repos/trice/src/triceRx.c.o
[ 79%] Building C object CMakeFiles/DemoData_Trice.dir/home/th/repos/trice/src/triceStackBuffer.c.o
[ 83%] Building C object CMakeFiles/DemoData_Trice.dir/home/th/repos/trice/src/triceStaticBuffer.c.o
[ 87%] Building C object CMakeFiles/DemoData_Trice.dir/home/th/repos/trice/src/triceUart.c.o
[ 91%] Building C object CMakeFiles/DemoData_Trice.dir/home/th/repos/trice/src/triceX0.c.o
[ 95%] Building C object CMakeFiles/DemoData_Trice.dir/home/th/repos/trice/src/xtea.c.o
[100%] Linking C executable DemoData_Trice
[100%] Built target DemoData_Trice
-- Installing: /home/th/repos/trice/examples/DemoData_Trice/bin/DemoData_Trice
Build completed in: /home/th/repos/trice/examples/DemoData_Trice/build
Executable installed in: /home/th/repos/trice/examples/DemoData_Trice/bin

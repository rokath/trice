-- Building for: MinGW Makefiles
-- The C compiler identification is GNU 16.2.0
-- Detecting C compiler ABI info
-- Detecting C compiler ABI info - done
-- Check for working C compiler: C:/Users/ms/repos/trice/temp/tools/host/winlibs-x86_64-posix-seh-gcc-16.2.0-llvm-23.1.3-mingw-w64ucrt-14.0.0-r3/mingw64/bin/gcc.exe - skipped
-- Detecting C compile features
-- Detecting C compile features - done
-- Configuring done (1.8s)
-- Generating done (0.3s)
-- Build files have been written to: C:/Users/ms/repos/trice/examples/DemoData_Trice/build
[  4%] Building C object CMakeFiles/DemoData_Trice.dir/src/main.c.obj
[  8%] Building C object CMakeFiles/DemoData_Trice.dir/C_/Users/ms/repos/trice/src/SEGGER_RTT.c.obj
[ 12%] Building C object CMakeFiles/DemoData_Trice.dir/C_/Users/ms/repos/trice/src/cobsDecode.c.obj
[ 16%] Building C object CMakeFiles/DemoData_Trice.dir/C_/Users/ms/repos/trice/src/cobsEncode.c.obj
[ 20%] Building C object CMakeFiles/DemoData_Trice.dir/C_/Users/ms/repos/trice/src/tcobsv1Decode.c.obj
[ 25%] Building C object CMakeFiles/DemoData_Trice.dir/C_/Users/ms/repos/trice/src/tcobsv1Encode.c.obj
[ 29%] Building C object CMakeFiles/DemoData_Trice.dir/C_/Users/ms/repos/trice/src/trice.c.obj
[ 33%] Building C object CMakeFiles/DemoData_Trice.dir/C_/Users/ms/repos/trice/src/trice16.c.obj
[ 37%] Building C object CMakeFiles/DemoData_Trice.dir/C_/Users/ms/repos/trice/src/trice32.c.obj
[ 41%] Building C object CMakeFiles/DemoData_Trice.dir/C_/Users/ms/repos/trice/src/trice64.c.obj
[ 45%] Building C object CMakeFiles/DemoData_Trice.dir/C_/Users/ms/repos/trice/src/trice8.c.obj
[ 50%] Building C object CMakeFiles/DemoData_Trice.dir/C_/Users/ms/repos/trice/src/triceAuxiliary.c.obj
[ 54%] Building C object CMakeFiles/DemoData_Trice.dir/C_/Users/ms/repos/trice/src/triceDoubleBuffer.c.obj
[ 58%] Building C object CMakeFiles/DemoData_Trice.dir/C_/Users/ms/repos/trice/src/triceLog.c.obj
[ 62%] Building C object CMakeFiles/DemoData_Trice.dir/C_/Users/ms/repos/trice/src/triceLogAnsi.c.obj
[ 66%] Building C object CMakeFiles/DemoData_Trice.dir/C_/Users/ms/repos/trice/src/triceLogMinimal.c.obj
[ 70%] Building C object CMakeFiles/DemoData_Trice.dir/C_/Users/ms/repos/trice/src/triceRingBuffer.c.obj
[ 75%] Building C object CMakeFiles/DemoData_Trice.dir/C_/Users/ms/repos/trice/src/triceRx.c.obj
[ 79%] Building C object CMakeFiles/DemoData_Trice.dir/C_/Users/ms/repos/trice/src/triceStackBuffer.c.obj
[ 83%] Building C object CMakeFiles/DemoData_Trice.dir/C_/Users/ms/repos/trice/src/triceStaticBuffer.c.obj
[ 87%] Building C object CMakeFiles/DemoData_Trice.dir/C_/Users/ms/repos/trice/src/triceUart.c.obj
[ 91%] Building C object CMakeFiles/DemoData_Trice.dir/C_/Users/ms/repos/trice/src/triceX0.c.obj
[ 95%] Building C object CMakeFiles/DemoData_Trice.dir/C_/Users/ms/repos/trice/src/xtea.c.obj
[100%] Linking C executable DemoData_Trice.exe
[100%] Built target DemoData_Trice
-- Installing: C:/Users/ms/repos/trice/examples/DemoData_Trice/bin/DemoData_Trice.exe
Build completed in: /c/Users/ms/repos/trice/examples/DemoData_Trice/build
Executable installed in: /c/Users/ms/repos/trice/examples/DemoData_Trice/bin

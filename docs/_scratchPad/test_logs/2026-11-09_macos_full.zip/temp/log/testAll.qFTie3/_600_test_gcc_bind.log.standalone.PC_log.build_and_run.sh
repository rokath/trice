INFO: PC_log uses local output; no project RTT header or J-Link installation is needed.
             [0;92;40mPC local log is running[0m
             value=-42 hex=0000002a
             text:runtime=[hello from triceS]
             text:width and precision=[abcde       ]
             float:single=+3.125 scientific=-3.12e-02
             float:double=3.141592654 compact=123456
             special:binary=0b101 bool=true octal=0o11 pointer=ab quoted='A'
             text:quoted="line 1\n\"line 2\""
             buffer:0001 002a 1234 
             [0;38;5;11;42m line 113[0m
[0;7;34;103m 0:00:00,000[0m Hello World!
[0;7;34;103m 0:00:00,000[0m [0;1;36;109mThis is a message without values and a 32-bit stamp.[0m
[0;7;34;103m       0_910[0m [0;1;36;109mThis is a message without values and a 16-bit stamp.[0m
             [0;1;36;109mThis is a message without values and without stamp.[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.,0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.,0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.,0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.,[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.,0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.,0[0m
             [0;4;30;103m[0m
             [0;4;30;103m0[0m
             [0;4;30;103m01[0m
             [0;4;30;103m012[0m
             [0;4;30;103m0123[0m
             [0;4;30;103m01234[0m
             [0;4;30;103m012345[0m
             [0;4;30;103m0123456[0m
             [0;4;30;103m01234567[0m
             [0;4;30;103m012345678[0m
             [0;4;30;103m0123456789[0m
             [0;4;30;103m0123456789a[0m
             [0;4;30;103m0123456789ab[0m
             [0;4;30;103m0123456789abc[0m
             [0;4;30;103m0123456789abcd[0m
             [0;4;30;103m0123456789abcde[0m
             [0;4;30;103m0123456789abcdef[0m
             [0;4;30;103m0123456789abcdefg[0m
             [0;4;30;103m0123456789abcdefgh[0m
             [0;4;30;103m0123456789abcdefghi[0m
             [0;4;30;103m0123456789abcdefghij[0m
             [0;4;30;103m0123456789abcdefghijk[0m
             [0;4;30;103m0123456789abcdefghijkl[0m
             [0;4;30;103m0123456789abcdefghijklm[0m
             [0;4;30;103m0123456789abcdefghijklmn[0m
             [0;4;30;103m0123456789abcdefghijklmno[0m
             [0;4;30;103m0123456789abcdefghijklmnop[0m
             [0;4;30;103m0123456789abcdefghijklmnopq[0m
             [0;4;30;103m0123456789abcdefghijklmnopqr[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrs[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrst[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstu[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuv[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvw[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwx[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxy[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyz[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyzA[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyzAB[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyzABC[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyzABCD[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyzABCDE[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyzABCDEF[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyzABCDEFG[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyzABCDEFGH[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHI[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJ[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJK[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKL[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLM[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMN[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNO[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOP[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQ[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQR[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRS[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRST[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTU[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUV[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVW[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWX[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXY[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.[0m
             [0;4;30;103m0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.,[0m
             [0;7;33;44mASSERT:flag not true![0m
[0;7;34;103m       0_665[0m [0;7;33;44mASSERT:flag not true![0m
[0;7;34;103m 0:00:00,001[0m [0;7;33;44mASSERT:flag not true![0m
             [0;7;33;44mASSERT:flag not true![0m
[0;7;34;103m       0_678[0m [0;7;33;44mASSERT:flag not true![0m
[0;7;34;103m 0:00:00,001[0m [0;7;33;44mASSERT:flag not true![0m
             [0;7;33;44mASSERT:flag not false![0m
[0;7;34;103m       0_691[0m [0;7;33;44mASSERT:flag not false![0m
[0;7;34;103m 0:00:00,001[0m [0;7;33;44mASSERT:flag not false![0m
             [0;7;33;44mASSERT:flag not true![0m
[0;7;34;103m       0_705[0m [0;7;33;44mASSERT:flag not true![0m
[0;7;34;103m 0:00:00,001[0m [0;7;33;44mASSERT:flag not true![0m
             [0;38;5;11;41mfile not found (error code 7)[0m
             [0;38;5;11;41munknown error code 9[0m
             [0;38;5;11;41mfile not found (error code 7)[0m
             [0;38;5;11;41munknown error code 9[0m
[0;7;34;103m 0:00:00,001[0m ok
[0;7;34;103m 0:00:00,001[0m ok
[0;7;34;103m 0:00:00,001[0m ok
[0;7;34;103m 0:00:00,001[0m ok
[0;7;34;103m 0:00:00,001[0m ok
[0;7;34;103m 0:00:00,001[0m ok
[0;7;34;103m 0:00:00,001[0m ok
[0;7;34;103m 0:00:00,001[0m ok
[0;7;34;103m 0:00:00,001[0m ok
[0;7;34;103m 0:00:00,001[0m ok
[0;7;34;103m 0:00:00,001[0m ok
[0;7;34;103m 0:00:00,001[0m ok
[0;7;34;103m 0:00:00,001[0m ok
[0;7;34;103m 0:00:00,001[0m ok
[0;7;34;103m 0:00:00,001[0m ok
             [0;1;36;109mSmall 7[0m
[0;7;34;103m       0_739[0m [0;1;36;109mCurrent -123 mA[0m
[0;7;34;103m 0:00:00,001[0m [0;1;36;109mVoltage 3300 mV[0m
             [0;1;36;109mBytes 1234567890123[0m
             [0;1;36;109mState 3 rpm 1200 / 1[0m
             [0;1;36;109mTemp 23.5 C[0m
[0;7;34;103m       0_777[0m [0;1;36;109mEnergy 12.25 J[0m
             [0;1;36;109mDevice pump[0m
             [0;1;36;109mCode READY[0m
             [0;1;36;109mpos:Position sample[0m
             [0;1;36;109mspeed:Speed sample[0m
[0;7;34;103m       0_789[0m [0;1;36;109mpos:speed:Moving sample=3[0m
[0;7;34;103m 0:00:00,001[0m [0;1;36;109mpos:Fixed sample=4[0m
             [0;1;36;109mspeed:Speed sample[0m
[0;7;34;103m       0_797[0m [0;1;36;109mpos:speed:Moving sample=5[0m
[0;7;34;103m 0:00:00,001[0m [0;1;36;109mpos:Fixed sample=4[0m
[0;7;34;103m 0:00:00,001[0m [0;1;36;109mpos:Fixed sample=4[0m
[0;7;34;103m 0:00:00,001[0m [0;1;36;109mpos:Fixed sample=6[0m
[0;7;34;103m 0:00:00,001[0m [0;1;36;109mpos:Fixed sample=6[0m
[0;7;34;103m 0:00:00,001[0m [0;1;36;109mpos:Fixed sample=6[0m
             [0;7;39;109mFixed value=7[0m
             [0;7;39;109mFixed value=7[0m
             [0;7;39;109mFixed value=7[0m
             [0;92;40mFixed value=8[0m
             [0;92;40mFixed value=8[0m
             [0;92;40mFixed value=8[0m
             [0;7;38;5;130mFixed value=9[0m
             [0;7;38;5;130mFixed value=9[0m
             [0;7;38;5;130mFixed value=9[0m
             [0;7;38;5;118mlength modifier coverage for supported combinations[0m
             len:hh -128 -1 255 377 0o377 ff FF 10100101
             len:h -32768 -1 65535 177777 0o177777 ffff FFFF 1010010101011010
             len:l -2147483648 -1 4294967295 37777777777 0o37777777777 ffffffff FFFFFFFF 10000000000000000000000000000001
             len:ll -9223372036854775808 -1 18446744073709551615 1777777777777777777777 0o1777777777777777777777 ffffffffffffffff FFFFFFFFFFFFFFFF 1000000000000000000000000000000000000000000000000000000000000001
             len:j -9223372036854775807 -123456789 18446744073709551615 1777777777777777777777 0o1777777777777777777777 ffffffffffffffff FFFFFFFFFFFFFFFF 1111000011110000111100001111000011110000111100001111000011110000
             len:z -9223372036854775807 -17 18446744073709551615 1777777777777777777777 0o1777777777777777777777 ffffffffffffffff FFFFFFFFFFFFFFFF 1010101010101010101010101010101001010101010101010101010101010101
             len:t -9223372036854775807 -33 18446744073709551615 1777777777777777777777 0o1777777777777777777777 ffffffffffffffff FFFFFFFFFFFFFFFF 100100011010001010110011110001001101010111100110111101111
             len:float-l -7.123457e+00 -7.123457 -7.12346 -7.123457E+00 -7.123457 -7.12346
             len:float-L -7.123457e+00 -7.123457 -7.12346 -7.123457E+00 -7.123457 -7.12346
             [0;7;38;5;118mtrice without stamp and with 0 to 12 values (most common use cases)[0m
             [0;7;30;103mtrice[0m
             [0;7;30;103mtrice -1[0m
             [0;7;30;103mtrice -1, -2[0m
             [0;7;30;103mtrice -1, -2, -3[0m
             [0;7;30;103mtrice -1, -2, -3, -4[0m
             [0;7;30;103mtrice -1, -2, -3, -4, -5[0m
             [0;7;30;103mtrice -1, -2, -3, -4, -5, -6[0m
             [0;7;30;103mtrice -1, -2, -3, -4, -5, -6, -7[0m
             [0;7;30;103mtrice -1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;7;30;103mtrice -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
             [0;7;30;103mtrice -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
             [0;7;30;103mtrice -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;7;30;103mtrice -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m       0_007[0m [0;7;38;5;118mTrice with 16-bit stamp and with 0 to 12 values (common use cases)[0m
[0;7;34;103m       0_012[0m [0;7;30;103mTrice[0m
[0;7;34;103m       0_015[0m [0;7;30;103mTrice -1[0m
[0;7;34;103m       0_018[0m [0;7;30;103mTrice -1, -2[0m
[0;7;34;103m       0_022[0m [0;7;30;103mTrice -1, -2, -3[0m
[0;7;34;103m       0_026[0m [0;7;30;103mTrice -1, -2, -3, -4[0m
[0;7;34;103m       0_030[0m [0;7;30;103mTrice -1, -2, -3, -4, -5[0m
[0;7;34;103m       0_034[0m [0;7;30;103mTrice -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m       0_039[0m [0;7;30;103mTrice -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m       0_043[0m [0;7;30;103mTrice -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m       0_049[0m [0;7;30;103mTrice -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m       0_054[0m [0;7;30;103mTrice -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m       0_060[0m [0;7;30;103mTrice -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m       0_065[0m [0;7;30;103mTrice -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m 0:00:00,002[0m [0;7;38;5;118mTRice with 32-bit stamp and with 0 to 12 values (common use cases)[0m
[0;7;34;103m 0:00:00,002[0m [0;7;30;103mTRice[0m
[0;7;34;103m 0:00:00,002[0m [0;7;30;103mTRice -1[0m
[0;7;34;103m 0:00:00,002[0m [0;7;30;103mTRice -1, -2[0m
[0;7;34;103m 0:00:00,002[0m [0;7;30;103mTRice -1, -2, -3[0m
[0;7;34;103m 0:00:00,002[0m [0;7;30;103mTRice -1, -2, -3, -4[0m
[0;7;34;103m 0:00:00,002[0m [0;7;30;103mTRice -1, -2, -3, -4, -5[0m
[0;7;34;103m 0:00:00,002[0m [0;7;30;103mTRice -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m 0:00:00,002[0m [0;7;30;103mTRice -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m 0:00:00,002[0m [0;7;30;103mTRice -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m 0:00:00,002[0m [0;7;30;103mTRice -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m 0:00:00,002[0m [0;7;30;103mTRice -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m 0:00:00,002[0m [0;7;30;103mTRice -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m 0:00:00,002[0m [0;7;30;103mTRice -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
             [0;7;38;5;118mtrice16 with 1 to 12 pointer[0m
             [0;7;30;103mtrice16 ffff[0m
             [0;7;30;103mtrice16 ffff, fffe[0m
             [0;7;30;103mtrice16 ffff, fffe, fffd[0m
             [0;7;30;103mtrice16 ffff, fffe, fffd, fffc[0m
             [0;7;30;103mtrice16 ffff, fffe, fffd, fffc, fffb[0m
             [0;7;30;103mtrice16 ffff, fffe, fffd, fffc, fffb, fffa[0m
             [0;7;30;103mtrice16 ffff, fffe, fffd, fffc, fffb, fffa, fff9[0m
             [0;7;30;103mtrice16 ffff, fffe, fffd, fffc, fffb, fffa, fff9, fff8[0m
             [0;7;30;103mtrice16 ffff, fffe, fffd, fffc, fffb, fffa, fff9, fff8, fff7[0m
             [0;7;30;103mtrice16 ffff, fffe, fffd, fffc, fffb, fffa, fff9, fff8, fff7, fff6[0m
             [0;7;30;103mtrice16 ffff, fffe, fffd, fffc, fffb, fffa, fff9, fff8, fff7, fff6, fff5[0m
             [0;7;30;103mtrice16 ffff, fffe, fffd, fffc, fffb, fffa, fff9, fff8, fff7, fff6, fff5, fff4[0m
             [0;7;30;103mtrice8  ff, fe, fd, fc, fb, fa, f9, f8, f7, f6, f5, f4[0m
             [0;7;30;103mtrice32 ffffffff, fffffffe, fffffffd, fffffffc, fffffffb, fffffffa, fffffff9, fffffff8, fffffff7, fffffff6, fffffff5, fffffff4[0m
             [0;7;38;5;118mtrice16 with 1 to 12 hex[0m
             [0;7;30;103mtrice16 FFFF[0m
             [0;7;30;103mtrice16 FFFF, FFFE[0m
             [0;7;30;103mtrice16 FFFF, FFFE, FFFD[0m
             [0;7;30;103mtrice16 FFFF, FFFE, FFFD, FFFC[0m
             [0;7;30;103mtrice16 FFFF, FFFE, FFFD, FFFC, FFFB[0m
             [0;7;30;103mtrice16 FFFF, FFFE, FFFD, FFFC, FFFB, FFFA[0m
             [0;7;30;103mtrice16 FFFF, FFFE, FFFD, FFFC, FFFB, FFFA, FFF9[0m
             [0;7;30;103mtrice16 FFFF, FFFE, FFFD, FFFC, FFFB, FFFA, FFF9, FFF8[0m
             [0;7;30;103mtrice16 FFFF, FFFE, FFFD, FFFC, FFFB, FFFA, FFF9, FFF8, FFF7[0m
             [0;7;30;103mtrice16 FFFF, FFFE, FFFD, FFFC, FFFB, FFFA, FFF9, FFF8, FFF7, FFF6[0m
             [0;7;30;103mtrice16 FFFF, FFFE, FFFD, FFFC, FFFB, FFFA, FFF9, FFF8, FFF7, FFF6, FFF5[0m
             [0;7;30;103mtrice16 FFFF, FFFE, FFFD, FFFC, FFFB, FFFA, FFF9, FFF8, FFF7, FFF6, FFF5, FFF4[0m
             [0;7;30;103mtrice8  FF, FE, FD, FC, FB, FA, F9, F8, F7, F6, F5, F4[0m
             [0;7;30;103mtrice32 FFFFFFFF, FFFFFFFE, FFFFFFFD, FFFFFFFC, FFFFFFFB, FFFFFFFA, FFFFFFF9, FFFFFFF8, FFFFFFF7, FFFFFFF6, FFFFFFF5, FFFFFFF4[0m
             [0;38;5;11;42m line 435[0m
             [0;38;5;11;42m line 458[0m
             [0;7;38;5;130mHi![0m
             [0;7;38;5;130m	Hi![0m
             [0;7;38;5;118mSome time measurements[0m
             [0;7;35;109mtrice isr message, SysTick is      0[0m
             [0;7;35;109mtrice isr message, SysTick is      0[0m
             [0;7;35;109mtrice isr message, SysTick is      0[0m
             [0;7;35;109mtrice isr message, SysTick is      0[0m
             [0;7;35;109mtrice_1 isr message, SysTick is      0[0m
             [0;7;35;109mtrice_1 isr message, SysTick is      0[0m
             [0;7;35;109mtrice_1 isr message, SysTick is      0[0m
             [0;7;35;109mtrice_1 isr message, SysTick is      0[0m
             [0;7;35;109mTRICE16_1 isr message, SysTick is      0[0m
             [0;7;35;109mTRICE16_1 isr message, SysTick is      0[0m
             [0;7;35;109mTRICE16_1 isr message, SysTick is      0[0m
             [0;7;35;109mTRICE16_1 isr message, SysTick is      0[0m
             [0;7;35;109mTRICE_1 isr message, SysTick is      0[0m
             [0;7;35;109mTRICE_1 isr message, SysTick is      0[0m
             [0;7;35;109mTRICE_1 isr message, SysTick is      0[0m
             [0;7;35;109mTRICE_1 isr message, SysTick is      0[0m
             [0;7;35;109mTRICE isr message, SysTick is      0[0m
             [0;7;35;109mTRICE isr message, SysTick is      0[0m
             [0;7;35;109mTRICE isr message, SysTick is      0[0m
             [0;7;35;109mTRICE isr message, SysTick is      0[0m
             [0;7;34;103mtrice START time message[0m
             [0;7;34;103mtrice STOP time message[0m
             [0;7;34;103mtrice START time message[0m
             [0;7;34;103mtrice STOP time message[0m
             [0;7;34;103mtrice START time message[0m
             [0;7;30;103mtrice64 1, 2[0m
             [0;7;34;103mtrice STOP time message[0m
             [0;7;34;103mTRICE START time message[0m
             [0;7;34;103mTRICE STOP time message[0m
             [0;7;34;103mTRICE START time message[0m
             [0;7;34;103mTRICE STOP time message[0m
             [0;7;34;103mTRICE START time message[0m
             [0;7;30;103mTRICE64 1, 2[0m
             [0;7;34;103mTRICE STOP time message[0m
             [0;7;34;103mtrice --------------------------------------------------[0m
             [0;7;34;103mtrice --------------------------------------------------[0m
             [0;7;30;103mtrice64 1, 2[0m
             [0;7;34;103mtrice --------------------------------------------------[0m
             [0;7;34;103mtrice --------------------------------------------------[0m
             [0;7;30;103mtrice64 1, 2[0m
             [0;7;30;103mtrice32_1 -1[0m
             [0;7;30;103mtrice64_1 -2[0m
             [0;7;30;103mtrice32_2 -1,2[0m
             [0;7;30;103mtrice64_2 -1,2[0m
[0;7;34;103m 0:00:00,002[0m [0;1;36;109m12 64-bit values -3, 18446744073709551612, fffffffffffffffb, FFFFFFFFFFFFFFFA, false, -7.123457e+00, -7.123457, -7.12346, -7.123457E+00, -7.123457, -7.12346, 0xb1111111111111111111111111111111111111111111111111111111111111000 and a 32-bit stamp.[0m
[0;7;34;103m       0_538[0m [0;1;36;109m12 64-bit values -3, 18446744073709551612, fffffffffffffffb, FFFFFFFFFFFFFFFA, false, -7.123457e+00, -7.123457, -7.12346, -7.123457E+00, -7.123457, -7.12346, 0xb1111111111111111111111111111111111111111111111111111111111111000 and a 16-bit stamp.[0m
             [0;1;36;109m12 64-bit values -3, 18446744073709551612, fffffffffffffffb, FFFFFFFFFFFFFFFA, false, -7.123457e+00, -7.123457, -7.12346, -7.123457E+00, -7.123457, -7.12346, 0xb1111111111111111111111111111111111111111111111111111111111111000 and without stamp.[0m
[0;7;34;103m 0:00:00,002[0m [0;1;36;109m12 64-bit values -3, 18446744073709551612, fffffffffffffffb, FFFFFFFFFFFFFFFA, false, -7.123457e+00, -7.123457, -7.12346, -7.123457E+00, -7.123457, -7.12346, 0xb1111111111111111111111111111111111111111111111111111111111111000 and a 32-bit stamp.[0m
[0;7;34;103m       0_564[0m [0;1;36;109m12 64-bit values -3, 18446744073709551612, fffffffffffffffb, FFFFFFFFFFFFFFFA, false, -7.123457e+00, -7.123457, -7.12346, -7.123457E+00, -7.123457, -7.12346, 0xb1111111111111111111111111111111111111111111111111111111111111000 and a 16-bit stamp.[0m
             [0;1;36;109m12 64-bit values -3, 18446744073709551612, fffffffffffffffb, FFFFFFFFFFFFFFFA, false, -7.123457e+00, -7.123457, -7.12346, -7.123457E+00, -7.123457, -7.12346, 0xb1111111111111111111111111111111111111111111111111111111111111000 and without stamp.[0m
[0;7;34;103m 0:00:00,002[0m [0;1;36;109m12 32-bit values -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12 and a 32-bit stamp.[0m
[0;7;34;103m       0_586[0m [0;1;36;109m12 32-bit values -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12 and a 16-bit stamp.[0m
             [0;1;36;109m12 32-bit values -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12 and without stamp.[0m
[0;7;34;103m 0:00:00,002[0m [0;1;36;109m12 16-bit values -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12 and a 32-bit stamp.[0m
[0;7;34;103m       0_625[0m [0;1;36;109m12 16-bit values -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12 and a 16-bit stamp.[0m
             [0;1;36;109m12 16-bit values -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12 and without stamp.[0m
[0;7;34;103m 0:00:00,002[0m [0;1;36;109m12  8-bit values -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12 and a 32-bit stamp.[0m
[0;7;34;103m       0_645[0m [0;1;36;109m12  8-bit values -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12 and a 16-bit stamp.[0m
             [0;1;36;109m12  8-bit values -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12 and without stamp.[0m
             [0;38;5;11;42m line 527[0m
[0;7;34;103m 0:00:00,002[0m [0;38;5;11;42m 0x8888 == 8888h[0m
[0;7;34;103m       0_663[0m [0;38;5;11;42m 0x8888 == 8888h[0m
             [0;38;5;11;42m 0x8888 == 8888h[0m
             [0;38;5;11;42m line 534[0m
             value=55
             value=88
             [0;38;5;11;42mmixed int & float & double & bits[0m
[0;7;34;103m 0:00:00,002[0m [0;7;30;103mTRice32 int 1089, float 1089.608276 (%f), 44883377, 01000100100010000011001101110111[0m
[0;7;34;103m 0:00:00,002[0m [0;7;30;103mTRice32 int 1089, float 1089.608276 (%f), 44883377, 01000100100010000011001101110111[0m
[0;7;34;103m 0:00:00,002[0m [0;7;30;103mTRice32 int 44883377, float 1089.608276 (%f), 44883377, 01000100100010000011001101110111[0m
[0;7;34;103m 0:00:00,002[0m [0;7;30;103mTRice32 int 1089, float 1089.608276 (%f), 44883377, 01000100100010000011001101110111[0m
[0;7;34;103m 0:00:00,002[0m [0;7;30;103mTRice32 int -1089, float -1089.608276 (%f), c4883377, 11000100100010000011001101110111[0m
[0;7;34;103m 0:00:00,002[0m [0;7;30;103mTRice32 int -1089, float -1089.608276 (%f), c4883377, 11000100100010000011001101110111[0m
[0;7;34;103m 0:00:00,002[0m [0;7;30;103mTRice32 int BB77CC89, float -1089.608276 (%f), c4883377, 11000100100010000011001101110111[0m
[0;7;34;103m 0:00:00,002[0m [0;7;30;103mTRice64 int 518, double 518.054749 (%f), 4080307020601050, 0100000010000000001100000111000000100000011000000001000001010000[0m
[0;7;34;103m 0:00:00,002[0m [0;7;30;103mTRice64 int 518, double 518.054749 (%f), 4080307020601050, 0100000010000000001100000111000000100000011000000001000001010000[0m
[0;7;34;103m 0:00:00,002[0m [0;7;30;103mTRice64 int 518, double 518.054749 (%f), 4080307020601050, 0100000010000000001100000111000000100000011000000001000001010000[0m
[0;7;34;103m 0:00:00,002[0m [0;7;30;103mTRice64 int -518, double -518.054749 (%f), c080307020601050, 1100000010000000001100000111000000100000011000000001000001010000[0m
[0;7;34;103m 0:00:00,002[0m [0;7;30;103mTRice64 int -518, double -518.054749 (%f), c080307020601050, 1100000010000000001100000111000000100000011000000001000001010000[0m
[0;7;34;103m 0:00:00,002[0m [0;7;30;103mTRice64 int BF7FCF8FDF9FEFB0, double -518.054749 (%f), c080307020601050, 1100000010000000001100000111000000100000011000000001000001010000[0m
             [0;38;5;11;42m line 553[0m
             [0;92;40mWith triceS:abcde 12345[0m
             [0;7;38;5;118mWith triceN:abcde 12345[0m
[0;7;34;103m       0_764[0m [0;92;40mWith TriceS:abcde 12345[0m
[0;7;34;103m       0_767[0m [0;7;38;5;118mWith TriceN:abcde 12345[0m
[0;7;34;103m 0:00:00,002[0m [0;92;40mWith TRiceS:abcde 12345[0m
[0;7;34;103m 0:00:00,002[0m [0;7;38;5;118mWith TRiceN:abcde 12345[0m
             [0;92;40mWith TRICE_S:abcde 12345[0m
             [0;7;38;5;118mWith TRICE_N:abcde 12345[0m
[0;7;34;103m       0_787[0m [0;92;40mWith TRICE_S:abcde 12345[0m
[0;7;34;103m       0_790[0m [0;7;38;5;118mWith TRICE_N:abcde 12345[0m
[0;7;34;103m 0:00:00,002[0m [0;92;40mWith TRICE_S:abcde 12345[0m
[0;7;34;103m 0:00:00,002[0m [0;7;38;5;118mWith TRICE_N:abcde 12345[0m
[0;7;34;103m 0:00:00,002[0m   61  62  63  64  65  20  31  32  33  34  35
[0;7;34;103m 0:00:00,002[0m BUF: 61 62 63 64 65 20 31 32 33 34 35
[0;7;34;103m 0:00:00,002[0m   97  98  99 100 101  32  49  50  51  52  53
[0;7;34;103m 0:00:00,002[0m   00  ff  fe  33  04  05  06  07  08  09  0a  0b  00  ff  fe  33  04  05  06  07  08  09  0a  0b
[0;7;34;103m 0:00:00,002[0m  00 ff fe 33 04 05 06 07 08 09 0a 0b 00 ff fe 33 04 05 06 07 08 09 0a 0b
[0;7;34;103m       0_850[0m  00 ff fe 33 04 05 06 07 08 09 0a 0b 00 ff fe 33 04 05 06 07 08 09 0a 0b
              00 ff fe 33 04 05 06 07 08 09 0a 0b 00 ff fe 33 04 05 06 07 08 09 0a 0b
             [0;38;5;11;42m 00 ff fe 33 04 05 06 07 08 09 0a 0b 00 ff fe 33 04 05 06 07 08 09 0a 0b[0m
             [0;7;30;103m 00 ff fe 33 04 05 06 07 08 09 0a 0b 00 ff fe 33 04 05 06 07 08 09 0a 0b[0m
              00 ff fe 33 04 05 06 07 08 09 0a 0b 00 ff fe 33 04 05 06 07 08 09 0a 0b
[0;7;34;103m 0:00:00,002[0m   0000  ffff  fffe  3344
[0;7;34;103m 0:00:00,002[0m  0000 ffff fffe 3344
[0;7;34;103m       0_893[0m  0000 ffff fffe 3344
              0000 ffff fffe 3344
             [0;92;40m 0000 ffff fffe 3344[0m
[0;7;34;103m 0:00:00,002[0m  00000000 ffffffff fffffffe 33445555
[0;7;34;103m 0:00:00,002[0m  00000000 ffffffff fffffffe 33445555
[0;7;34;103m       0_906[0m  00000000 ffffffff fffffffe 33445555
              00000000 ffffffff fffffffe 33445555
             [0;38;5;11;42m 00000000 ffffffff fffffffe 33445555[0m
[0;7;34;103m 0:00:00,002[0m  0000000000000000 ffffffffffffffff fffffffffffffffe 3344555566666666
[0;7;34;103m 0:00:00,002[0m  0000000000000000 ffffffffffffffff fffffffffffffffe 3344555566666666
[0;7;34;103m       0_917[0m  0000000000000000 ffffffffffffffff fffffffffffffffe 3344555566666666
              0000000000000000 ffffffffffffffff fffffffffffffffe 3344555566666666
             [0;7;38;5;118mSIG: 0000000000000000 ffffffffffffffff fffffffffffffffe 3344555566666666[0m
[0;7;34;103m 0:00:00,002[0m [0;92;40mHi five![0m
[0;7;34;103m       0_932[0m [0;92;40mHi five![0m
             [0;92;40mHi five![0m
[0;7;34;103m 0:00:00,002[0m [0;92;40mHi five![0m
[0;7;34;103m       0_942[0m [0;92;40mHi five![0m
             [0;92;40mHi five![0m
             [0;7;38;5;118mTRICE_S=AAAAAAAAAAAA[0m
             [0;7;38;5;118mTRICE_N=AAAAAAAAAAAA[0m
[0;7;34;103m       0_979[0m [0;7;38;5;118mTRICE_S=AAAAAAAAAAAA[0m
[0;7;34;103m       0_983[0m [0;7;38;5;118mTRICE_N=AAAAAAAAAAAA[0m
[0;7;34;103m 0:00:00,002[0m [0;7;38;5;118mTRICE_S=AAAAAAAAAAAA[0m
[0;7;34;103m 0:00:00,002[0m [0;7;38;5;118mTRICE_N=AAAAAAAAAAAA[0m
             [0;7;38;5;118mtriceS=AAAAAAAAAAAA[0m
             [0;7;38;5;118mtriceN=AAAAAAAAAAAA[0m
[0;7;34;103m       0_004[0m [0;7;38;5;118mTriceS=AAAAAAAAAAAA[0m
[0;7;34;103m       0_008[0m [0;7;38;5;118mTriceN=AAAAAAAAAAAA[0m
[0;7;34;103m 0:00:00,003[0m [0;7;38;5;118mTRiceS=AAAAAAAAAAAA[0m
[0;7;34;103m 0:00:00,003[0m [0;7;38;5;118mTRiceN=AAAAAAAAAAAA[0m
             [0;38;5;11;42m line 677[0m
[0;7;34;103m       0_023[0m [0;38;5;11;42mMyStructEvaluationFunction(json:ExA{Apple:-1, Birn:2, Fish:2.781000})[0m
[0;7;34;103m       0_028[0m [0;92;40mMSG:1/11 = 0.0909091[0m
[0;7;34;103m 0:00:00,003[0m [0;92;40mx = 5.934 = 5.934, 5.934[0m
             [0;38;5;11;42m line 692[0m
[0;7;34;103m 0:00:00,003[0m [0;7;38;5;118mInteger (indent, base, sign) - see https://yourbasic.org/golang/fmt-printf-reference-cheat-sheet/[0m
[0;7;34;103m 0:00:00,003[0m [0;7;30;103m 15 	15 	Base 10[0m
[0;7;34;103m 0:00:00,003[0m [0;7;30;103m +15 	+15 	Always show sign[0m
[0;7;34;103m 0:00:00,003[0m [0;7;30;103m   15	  15 	Pad with spaces (width 4, right justified)[0m
[0;7;34;103m 0:00:00,003[0m [0;7;30;103m    15	15  	Pad with spaces (width 4, left justified)[0m
[0;7;34;103m 0:00:00,003[0m [0;7;30;103m 0015	0015	Pad with zeroes (width 4)[0m
[0;7;34;103m 0:00:00,003[0m [0;7;30;103m 1111 	1111 	Base 2[0m
[0;7;34;103m 0:00:00,003[0m [0;7;30;103m 17 	17 	Base 8[0m
[0;7;34;103m 0:00:00,003[0m [0;7;30;103m f 	f 	Base 16, lowercase[0m
[0;7;34;103m 0:00:00,003[0m [0;7;30;103m F 	F 	Base 16, uppercase[0m
[0;7;34;103m 0:00:00,003[0m [0;7;30;103m 0xf 	0xf 	Base 16, with leading 0x[0m
             [0;38;5;11;42m line 706[0m
             [0;7;38;5;118mCharacter (quoted, Unicode)[0m
             [0;7;30;103m A 	A 	Character[0m
             [0;7;30;103m 'A' 	'A' 	Quoted character[0m
             [0;7;38;5;118mBoolean (true/false)[0m
             [0;7;30;103mUse %t to format a boolean as true (true) or false (false).[0m
             [0;7;38;5;118mPointer (hex)[0m
             [0;7;30;103mUse %p to format a pointer in base 16 notation with leading 0x. (84)[0m
             [0;7;30;103mUse %p to format a pointer in base 16 notation with leading 0x. (1234)[0m
             [0;7;30;103mUse %p to format a pointer in base 16 notation with leading 0x. (aabbccdd)[0m
             [0;7;30;103mUse %p to format a pointer in base 16 notation with leading 0x. (1122334455667788)[0m
             [0;7;30;103mUse %p to format a pointer in base 16 notation with leading 0x. (aabbccdd)[0m
             [0;38;5;11;42m line 724[0m
             [0;7;38;5;118mFloat (indent, precision, scientific notation)[0m
             [0;7;30;103m 1.234560e+02		1.234560e+02 	%e Scientific notation[0m
             [0;7;30;103m 123.456000		123.456001 	%f Decimal point, no exponent[0m
             [0;7;30;103m 123.46			123.46		%.2f Default width, precision 2[0m
             [0;7;30;103m ␣␣123.46		  123.46	%8.2f Width 8, precision 2[0m
             [0;7;30;103m 123.456		123.456		%g Exponent as needed, necessary digits only[0m
             [0;7;38;5;118mDouble (indent, precision, scientific notation)[0m
             [0;7;30;103m 1.234560e+02		1.234560e+02 	%e Scientific notation[0m
             [0;7;30;103m 123.456000		123.456000 	%f Decimal point, no exponent[0m
             [0;7;30;103m 123.46			123.46    	%.2f Default width, precision 2[0m
             [0;7;30;103m ␣␣123.46		  123.46 	%8.2f Width 8, precision 2[0m
             [0;7;30;103m 123.456		123.456		%g Exponent as needed, necessary digits only[0m
             [0;7;38;5;118mString or byte slice (quote, indent, hex)[0m
             [0;7;30;103m café 			café		Plain string[0m
             [0;7;30;103m ␣␣café 		 café 		Width 6, right justify[0m
             [0;7;30;103m café␣␣ 		café  		Width 6, left justify[0m
             [0;7;30;103m "café" 		"café"		Quoted string[0m
             [0;38;5;11;42m line 750[0m
             [0;7;30;103msizeof(       z)[0m = 4
             [0;7;30;103msizeof(       u)[0m = 2
             [0;7;30;103msizeof(       s)[0m = 1
             [0;7;30;103msizeof(    addr)[0m = 8
             [0;7;30;103msizeof(       x)[0m = 4
             [0;7;30;103msizeof(       y)[0m = 4
             [0;7;30;103msizeof(   names)[0m = 15
             [0;7;30;103msizeof(       x)[0m = 4
             [0;7;30;103msizeof(       y)[0m = 4
             [0;7;30;103msizeof(     rgb)[0m = 3
             [0;7;30;103msizeof( bitmask)[0m = 8
[0;7;34;103m       0_227[0m [0;1;36;109m Tryout tx struct:[0m 79  e9  f6  42  9c  ad  fe  00  ca  75  f8  02  01  00  00  00  77  bb  55  aa  c0  bd  f0  ff  61  61  61  00  a1  62  62  62  62  25  63  63  63  63  63  00  7b  14  0e  40  b8  1e  55  c0  88  25  fa  02  ec  51  85  c2  a8  c6  b1  40  bb  00  00  00  ff  ff  00  00  55  55  aa  aa 
[0;7;34;103m       0_227[0m [0;1;36;109m Tryout buffer:[0m 79  e9  f6  42  9c  ad  fe  ca  75  f8  02  01  00  00  00  77  bb  55  aa  c0  bd  f0  ff  61  61  61  00  a1  62  62  62  62  25  63  63  63  63  63  7b  14  0e  40  b8  1e  55  c0  88  25  fa  ff  ff  00  00  55  55  aa  aa 
             [0;7;30;103msizeof(       z)[0m = 4
             [0;7;30;103msizeof(       u)[0m = 2
             [0;7;30;103msizeof(       s)[0m = 1
             [0;7;30;103msizeof(    addr)[0m = 8
             [0;7;30;103msizeof(       x)[0m = 4
             [0;7;30;103msizeof(       y)[0m = 4
             [0;7;30;103msizeof(   names)[0m = 15
             [0;7;30;103msizeof(       x)[0m = 4
             [0;7;30;103msizeof(       y)[0m = 4
             [0;7;30;103msizeof(     rgb)[0m = 3
             [0;7;30;103msizeof( bitmask)[0m = 8
[0;7;34;103m       0_229[0m [0;1;36;109m Tryout rx struct:[0m 79  e9  f6  42  9c  ad  fe  00  ca  75  f8  02  01  00  00  00  77  bb  55  aa  c0  bd  f0  ff  61  61  61  00  a1  62  62  62  62  25  63  63  63  63  63  ff  7b  14  0e  40  b8  1e  55  c0  88  25  fa  fb  01  00  00  00  00  00  00  00  01  00  00  00  ff  ff  00  00  55  55  aa  aa 
[0;7;34;103m       0_230[0m [0;1;36;109msizeOf(Trypout) = 72, buffer length = 57[0m
[0;7;34;103m 0:00:00,003[0m [0;1;36;109m12 default bit width values -3, 4294967292, fffffffb, FFFFFFFA, true, -7.123457e+00, -7.123457, -7.12346, -7.123457E+00, -7.123457, -7.12346, 0xb11111111111111111111111111111000 and a 32-bit stamp.[0m
[0;7;34;103m       0_450[0m [0;1;36;109m12 default bit width values -3, 4294967292, fffffffb, FFFFFFFA, true, -7.123457e+00, -7.123457, -7.12346, -7.123457E+00, -7.123457, -7.12346, 0xb11111111111111111111111111111000 and a 16-bit stamp.[0m
             [0;1;36;109m12 default bit width values -3, 4294967292, fffffffb, FFFFFFFA, true, -7.123457e+00, -7.123457, -7.12346, -7.123457E+00, -7.123457, -7.12346, 0xb11111111111111111111111111111000 and without stamp.[0m
[0;7;34;103m 0:00:00,003[0m [0;1;36;109m12 default bit width values -3, 4294967292, fffffffb, FFFFFFFA, true, -7.123457e+00, -7.123457, -7.12346, -7.123457E+00, -7.123457, -7.12346, 0xb11111111111111111111111111111000 and a 32-bit stamp.[0m
[0;7;34;103m       0_472[0m [0;1;36;109m12 default bit width values -3, 4294967292, fffffffb, FFFFFFFA, true, -7.123457e+00, -7.123457, -7.12346, -7.123457E+00, -7.123457, -7.12346, 0xb11111111111111111111111111111000 and a 16-bit stamp.[0m
             [0;1;36;109m12 default bit width values -3, 4294967292, fffffffb, FFFFFFFA, true, -7.123457e+00, -7.123457, -7.12346, -7.123457E+00, -7.123457, -7.12346, 0xb11111111111111111111111111111000 and without stamp.[0m
             [0;38;5;11;42m line 762[0m
             [0;7;38;5;118mRuntime generated strings[0m
[0;7;34;103m 0:00:00,003[0m [0;7;38;5;130mlen=12:[0m[0;7;38;5;118mAAAAAAAAAAAA[0m
[0;7;34;103m 0:00:00,003[0m [0;7;38;5;130mlen=76:[0m[0;7;38;5;118mAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABBBBBBBBCCCCCCCC[0m
[0;7;34;103m 0:00:00,003[0m [0;7;38;5;130mlen=500: [0m[0;7;38;5;118mAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC[0m
[0;7;34;103m 0:00:00,003[0m [0;7;38;5;130mlen=800: [0m[0;7;38;5;118mAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC[0m
[0;7;34;103m 0:00:00,003[0m [0;7;38;5;130mlen=1600: [0m[0;7;38;5;118m0123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB[0m
             [0;7;30;103m-5.555556E+08 (%E)[0m
             [0;7;30;103m-555555584.000000 (%F)[0m
             [0;7;30;103m-5.55556E+08 (%G)[0m
             [0;7;30;103m-5.555556E+08 (%E)[0m
             [0;7;30;103m-555555555.555556 (%F)[0m
             [0;7;30;103m-5.55556E+08 (%G)[0m
             [0;7;30;103m-5.555556e+08 (%e)[0m
             [0;7;30;103m-555555584.000000 (%f)[0m
             [0;7;30;103m-5.55556e+08 (%g)[0m
             [0;7;30;103m-5.555556e+08 (%e)[0m
             [0;7;30;103m-555555555.555556 (%f)[0m
             [0;7;30;103m-5.55556e+08 (%g)[0m
             [0;92;40m4294967295 (%u)[0m
             [0;92;40m11111111111111111111111111111111 (%b)[0m
             [0;92;40m37777777777 (%o)[0m
             [0;92;40m0o37777777777 (%O)[0m
             [0;92;40mFFFFFFFF (%X)[0m
             [0;92;40mffffffff (%x)[0m
             [0;92;40m-1 (%d)[0m
             [0;92;40m18446744073709551615 (%u)[0m
             [0;92;40m1111111111111111111111111111111111111111111111111111111111111111 (%b)[0m
             [0;92;40m1777777777777777777777 (%o)[0m
             [0;92;40m0o1777777777777777777777 (%O)[0m
             [0;92;40mFFFFFFFFFFFFFFFF (%X)[0m
             [0;92;40mffffffffffffffff (%x)[0m
[0;7;34;103m 0:00:00,003[0m value=-2
[0;7;34;103m       0_643[0m value=-2
             value=-2
[0;7;34;103m 0:00:00,003[0m value=-2
[0;7;34;103m       0_649[0m value=-2
             value=-2
[0;7;34;103m 0:00:00,003[0m value=-2
[0;7;34;103m       0_656[0m value=-2
             value=-2
[0;7;34;103m 0:00:00,003[0m value=-2
[0;7;34;103m       0_662[0m value=-2
             value=-2
[0;7;34;103m 0:00:00,003[0m value=-2
[0;7;34;103m       0_669[0m value=-2
             value=-2
[0;7;34;103m 0:00:00,003[0m value=-2
[0;7;34;103m       0_676[0m value=-2
             value=-2
[0;7;34;103m 0:00:00,003[0m value=-2
[0;7;34;103m       0_682[0m value=-2
             value=-2
[0;7;34;103m 0:00:00,003[0m value=-2
[0;7;34;103m       0_688[0m value=-2
             value=-2
[0;7;34;103m 0:00:00,003[0m value=-2
[0;7;34;103m       0_695[0m value=-2
             value=-2
[0;7;34;103m 0:00:00,003[0m value=-2
[0;7;34;103m       0_701[0m value=-2
             value=-2
[0;7;34;103m 0:00:00,003[0m no value
[0;7;34;103m       0_707[0m no value
             no value
[0;7;34;103m 0:00:00,003[0m no value
[0;7;34;103m       0_710[0m no value
             no value
[0;7;34;103m 0:00:00,003[0m no value
[0;7;34;103m       0_713[0m no value
             no value
[0;7;34;103m 0:00:00,003[0m no value
[0;7;34;103m       0_716[0m no value
             no value
[0;7;34;103m 0:00:00,003[0m no value
[0;7;34;103m       0_719[0m no value
             no value
[0;7;34;103m 0:00:00,003[0m no value
[0;7;34;103m       0_722[0m no value
             no value
[0;7;34;103m 0:00:00,003[0m no value
[0;7;34;103m       0_725[0m no value
             no value
[0;7;34;103m 0:00:00,003[0m no value
[0;7;34;103m       0_728[0m no value
             no value
[0;7;34;103m 0:00:00,003[0m no value
[0;7;34;103m       0_731[0m no value
             no value
[0;7;34;103m 0:00:00,003[0m no value
[0;7;34;103m       0_734[0m no value
             no value
[0;7;34;103m 0:00:00,003[0m no value
[0;7;34;103m       0_737[0m no value
             no value
[0;7;34;103m 0:00:00,003[0m no value
[0;7;34;103m       0_739[0m no value
             no value
[0;7;34;103m 0:00:00,003[0m [0;1;36;109mThis is a message with one value -2 and a 32-bit stamp.[0m
[0;7;34;103m       0_745[0m [0;1;36;109mThis is a message with one value -2 and a 16-bit stamp.[0m
             [0;1;36;109mThis is a message with one value -2 and without stamp.[0m
[0;7;34;103m 0:00:00,003[0m [0;1;36;109mThis is a message without values and a 32-bit stamp.[0m
[0;7;34;103m       0_756[0m [0;1;36;109mThis is a message without values and a 16-bit stamp.[0m
             [0;1;36;109mThis is a message without values and without stamp.[0m
[0;7;34;103m 0:00:00,003[0m [0;1;36;109mThis is a message with one value -2 and a 32-bit stamp.[0m
[0;7;34;103m       0_767[0m [0;1;36;109mThis is a message with one value -2 and a 16-bit stamp.[0m
             [0;1;36;109mThis is a message with one value -2 and without stamp.[0m
[0;7;34;103m 0:00:00,003[0m [0;1;36;109m12 values -3, 4294967292, fffffffb, FFFFFFFA, true, -7.123457e+00, -7.123457, -7.12346, -7.123457E+00, -7.123457, -7.12346, 0xb11111111111111111111111111111000 and a 32-bit stamp.[0m
[0;7;34;103m       0_804[0m [0;1;36;109m12 values -3, 4294967292, fffffffb, FFFFFFFA, true, -7.123457e+00, -7.123457, -7.12346, -7.123457E+00, -7.123457, -7.12346, 0xb11111111111111111111111111111000 and a 16-bit stamp.[0m
             [0;1;36;109m12 values -3, 4294967292, fffffffb, FFFFFFFA, true, -7.123457e+00, -7.123457, -7.12346, -7.123457E+00, -7.123457, -7.12346, 0xb11111111111111111111111111111000 and without stamp.[0m
[0;7;34;103m 0:00:00,003[0m [0;1;36;109m12 values -3, 4294967292, fffffffb, FFFFFFFA, true, -7.123457e+00, -7.123457, -7.12346, -7.123457E+00, -7.123457, -7.12346, 0xb11111111111111111111111111111000 and a 32-bit stamp.[0m
[0;7;34;103m       0_840[0m [0;1;36;109m12 values -3, 4294967292, fffffffb, FFFFFFFA, true, -7.123457e+00, -7.123457, -7.12346, -7.123457E+00, -7.123457, -7.12346, 0xb11111111111111111111111111111000 and a 16-bit stamp.[0m
             [0;1;36;109m12 values -3, 4294967292, fffffffb, FFFFFFFA, true, -7.123457e+00, -7.123457, -7.12346, -7.123457E+00, -7.123457, -7.12346, 0xb11111111111111111111111111111000 and without stamp.[0m
             [0;92;40mvalue=200[0m
             [0;92;40mvalue=200[0m
[0;7;34;103m       0_861[0m [0;92;40mvalue=200[0m
[0;7;34;103m       0_865[0m [0;92;40mvalue=200[0m
[0;7;34;103m 0:00:00,003[0m [0;92;40mvalue=200[0m
[0;7;34;103m 0:00:00,003[0m [0;92;40mvalue=200[0m
             [0;92;40mvalue=200[0m
             [0;92;40mvalue=200[0m
[0;7;34;103m       0_883[0m [0;92;40mvalue=200[0m
[0;7;34;103m       0_887[0m [0;92;40mvalue=200[0m
[0;7;34;103m 0:00:00,003[0m [0;92;40mvalue=200[0m
[0;7;34;103m 0:00:00,003[0m [0;92;40mvalue=200[0m
             [0;92;40mvalue=200[0m
             [0;92;40mvalue=200[0m
[0;7;34;103m       0_905[0m [0;92;40mvalue=200[0m
[0;7;34;103m       0_908[0m [0;92;40mvalue=200[0m
[0;7;34;103m 0:00:00,003[0m [0;92;40mvalue=200[0m
[0;7;34;103m 0:00:00,003[0m [0;92;40mvalue=200[0m
             [0;92;40mvalue=200[0m
             [0;92;40mvalue=200[0m
[0;7;34;103m       0_926[0m [0;92;40mvalue=200[0m
[0;7;34;103m       0_930[0m [0;92;40mvalue=200[0m
[0;7;34;103m 0:00:00,003[0m [0;92;40mvalue=200[0m
[0;7;34;103m 0:00:00,003[0m [0;92;40mvalue=200[0m
             [0;92;40mvalue=200[0m
             [0;92;40mvalue=200[0m
[0;7;34;103m       0_948[0m [0;92;40mvalue=200[0m
[0;7;34;103m       0_951[0m [0;92;40mvalue=200[0m
[0;7;34;103m 0:00:00,003[0m [0;92;40mvalue=200[0m
[0;7;34;103m 0:00:00,003[0m [0;92;40mvalue=200[0m
             [0;92;40mvalue=200[0m
             [0;92;40mvalue=200[0m
[0;7;34;103m       0_969[0m [0;92;40mvalue=200[0m
[0;7;34;103m       0_973[0m [0;92;40mvalue=200[0m
[0;7;34;103m 0:00:00,003[0m [0;92;40mvalue=200[0m
[0;7;34;103m 0:00:00,003[0m [0;92;40mvalue=200[0m
             [0;92;40mvalue=200[0m
             [0;92;40mvalue=200[0m
[0;7;34;103m       0_991[0m [0;92;40mvalue=200[0m
[0;7;34;103m       0_995[0m [0;92;40mvalue=200[0m
[0;7;34;103m 0:00:00,003[0m [0;92;40mvalue=200[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=200[0m
             [0;92;40mvalue=200[0m
             [0;92;40mvalue=200[0m
[0;7;34;103m       0_013[0m [0;92;40mvalue=200[0m
[0;7;34;103m       0_017[0m [0;92;40mvalue=200[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=200[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=200[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=-1[0m
[0;7;34;103m       0_032[0m [0;92;40mvalue=-1, -2[0m
             [0;92;40mvalue=-1, -2, -3[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=-1, -2, -3, -4[0m
[0;7;34;103m       0_045[0m [0;92;40mvalue=-1, -2, -3, -4, -5[0m
             [0;92;40mvalue=-1, -2, -3, -4, -5, -6[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m       0_060[0m [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m       0_077[0m [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=-1[0m
[0;7;34;103m       0_093[0m [0;92;40mvalue=-1, -2[0m
             [0;92;40mvalue=-1, -2, -3[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=-1, -2, -3, -4[0m
[0;7;34;103m       0_118[0m [0;92;40mvalue=-1, -2, -3, -4, -5[0m
             [0;92;40mvalue=-1, -2, -3, -4, -5, -6[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m       0_134[0m [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m       0_172[0m [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=-1[0m
[0;7;34;103m       0_188[0m [0;92;40mvalue=-1, -2[0m
             [0;92;40mvalue=-1, -2, -3[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=-1, -2, -3, -4[0m
[0;7;34;103m       0_201[0m [0;92;40mvalue=-1, -2, -3, -4, -5[0m
             [0;92;40mvalue=-1, -2, -3, -4, -5, -6[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m       0_216[0m [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m       0_234[0m [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=-1[0m
[0;7;34;103m       0_251[0m [0;92;40mvalue=-1, -2[0m
             [0;92;40mvalue=-1, -2, -3[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=-1, -2, -3, -4[0m
[0;7;34;103m       0_265[0m [0;92;40mvalue=-1, -2, -3, -4, -5[0m
             [0;92;40mvalue=-1, -2, -3, -4, -5, -6[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m       0_281[0m [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m       0_300[0m [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=-1[0m
[0;7;34;103m       0_318[0m [0;92;40mvalue=-1, -2[0m
             [0;92;40mvalue=-1, -2, -3[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=-1, -2, -3, -4[0m
[0;7;34;103m       0_331[0m [0;92;40mvalue=-1, -2, -3, -4, -5[0m
             [0;92;40mvalue=-1, -2, -3, -4, -5, -6[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m       0_345[0m [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m       0_362[0m [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=-1[0m
[0;7;34;103m       0_379[0m [0;92;40mvalue=-1, -2[0m
             [0;92;40mvalue=-1, -2, -3[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=-1, -2, -3, -4[0m
[0;7;34;103m       0_392[0m [0;92;40mvalue=-1, -2, -3, -4, -5[0m
             [0;92;40mvalue=-1, -2, -3, -4, -5, -6[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m       0_407[0m [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m       0_424[0m [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=-1[0m
[0;7;34;103m       0_441[0m [0;92;40mvalue=-1, -2[0m
             [0;92;40mvalue=-1, -2, -3[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=-1, -2, -3, -4[0m
[0;7;34;103m       0_474[0m [0;92;40mvalue=-1, -2, -3, -4, -5[0m
             [0;92;40mvalue=-1, -2, -3, -4, -5, -6[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m       0_490[0m [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m       0_507[0m [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=-1[0m
[0;7;34;103m       0_524[0m [0;92;40mvalue=-1, -2[0m
             [0;92;40mvalue=-1, -2, -3[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=-1, -2, -3, -4[0m
[0;7;34;103m       0_538[0m [0;92;40mvalue=-1, -2, -3, -4, -5[0m
             [0;92;40mvalue=-1, -2, -3, -4, -5, -6[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m       0_554[0m [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m 0:00:00,004[0m [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m       0_573[0m [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;92;40mvalue=-1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
             value=-2
[0;7;34;103m       0_589[0m value=-3
[0;7;34;103m 0:00:00,004[0m value=-4
             value=-5
[0;7;34;103m       0_597[0m value=-6
[0;7;34;103m 0:00:00,004[0m value=-7
             value=-2
[0;7;34;103m       0_605[0m value=-3
[0;7;34;103m 0:00:00,004[0m value=-4
             value=-5
[0;7;34;103m       0_612[0m value=-6
[0;7;34;103m 0:00:00,004[0m value=-7
             value=-2
[0;7;34;103m       0_620[0m value=-3
[0;7;34;103m 0:00:00,004[0m value=-4
             value=-5
[0;7;34;103m       0_628[0m value=-6
[0;7;34;103m 0:00:00,004[0m value=-7
             value=-2
[0;7;34;103m       0_636[0m value=-3
[0;7;34;103m 0:00:00,004[0m value=-4
             value=-5
[0;7;34;103m       0_644[0m value=-6
[0;7;34;103m 0:00:00,004[0m value=-7
[0;7;34;103m 0:00:00,004[0m value=-3
             value=-4
[0;7;34;103m       0_655[0m value=-5
[0;7;34;103m 0:00:00,004[0m value=-6
[0;7;34;103m 0:00:00,004[0m value=-2
[0;7;34;103m 0:00:00,004[0m value=-3
             value=-3
             value=-4
             value=-5
             value=-6
[0;7;34;103m       0_676[0m value=-3
[0;7;34;103m       0_679[0m value=-4
[0;7;34;103m       0_681[0m value=-5
[0;7;34;103m       0_684[0m value=-6
[0;7;34;103m 0:00:00,004[0m value=-3
[0;7;34;103m 0:00:00,004[0m value=-4
[0;7;34;103m 0:00:00,004[0m value=-5
[0;7;34;103m 0:00:00,004[0m value=-6
             [0;1;35;41mFATAL:magenta+b:red[0m
             [0;7;31;109mCRITICAL:red+i:default+h[0m
             [0;7;31;44mEMERGENCY:red+i:blue[0m
             [0;38;5;11;41mERROR:11:red[0m
             [0;7;38;5;11;41mWARNING:11+i:red[0m
             [0;38;5;11;42mATTENTION:11:green[0m
             [0;1;36;109mINFO:cyan+b:default+h[0m
             [0;7;38;5;130mDEBUG:130+i[0m
             [0;7;39;109mTRACE:default+i:default+h[0m
             [0;7;34;103mTIME:blue+i:blue+h[0m
             [0;92;40mMESSAGE:green+h:black[0m
             [0;7;30;103mREAD:black+i:yellow+h[0m
             [0;4;30;103mWRITE:black+u:yellow+h[0m
             [0;90;40mRECEIVE:black+h:black[0m
             [0;30;100mTRANSMIT:black:black+h[0m
             [0;7;33;109mDIAG:yellow+i:default+h[0m
             [0;7;35;109mINTERRUPT:magenta+i:default+h[0m
             [0;7;38;5;118mSIGNAL:118+i[0m
             [0;93;40mTEST:yellow+h:black[0m
             DEFAULT:off
             [0;34;107mNOTICE:blue:white+h[0m
             [0;35;105mALERT:magenta:magenta+h[0m
             [0;7;33;44mASSERT:yellow+i:blue[0m
             [0;7;31;107mALARM:red+i:white+h[0m
             [0;34;49mVERBOSE:blue:default[0m
             [0;1;35;41mmagenta+b:red[0m
             [0;7;31;109mred+i:default+h[0m
             [0;7;31;44mred+i:blue[0m
             [0;38;5;11;41m11:red[0m
             [0;7;38;5;11;41m11+i:red[0m
             [0;38;5;11;42m11:green[0m
             [0;1;36;109mcyan+b:default+h[0m
             [0;7;38;5;130m130+i[0m
             [0;7;39;109mdefault+i:default+h[0m
             [0;7;34;103mblue+i:blue+h[0m
             [0;92;40mgreen+h:black[0m
             [0;7;30;103mblack+i:yellow+h[0m
             [0;4;30;103mblack+u:yellow+h[0m
             [0;90;40mblack+h:black[0m
             [0;30;100mblack:black+h[0m
             [0;7;33;109myellow+i:default+h[0m
             [0;7;35;109mmagenta+i:default+h[0m
             [0;7;38;5;118m118+i[0m
             [0;93;40myellow+h:black[0m
             off
             [0;34;107mblue:white+h[0m
             [0;35;105mmagenta:magenta+h[0m
             [0;7;33;44myellow+i:blue[0m
             [0;7;31;107mred+i:white+h[0m
             [0;34;49mblue:default[0m
             [0;1;35;41mFATAL:magenta+b:red[0m
             [0;7;31;109mCRITICAL:red+i:default+h[0m
             [0;7;31;44mEMERGENCY:red+i:blue[0m
             [0;38;5;11;41mERROR:11:red[0m
             [0;7;38;5;11;41mWARNING:11+i:red[0m
             [0;38;5;11;42mATTENTION:11:green[0m
             [0;1;36;109mINFO:cyan+b:default+h[0m
             [0;7;38;5;130mDEBUG:130+i[0m
             [0;7;39;109mTRACE:default+i:default+h[0m
             [0;7;34;103mTIME:blue+i:blue+h[0m
             [0;92;40mMESSAGE:green+h:black[0m
             [0;7;30;103mREAD:black+i:yellow+h[0m
             [0;4;30;103mWRITE:black+u:yellow+h[0m
             [0;90;40mRECEIVE:black+h:black[0m
             [0;30;100mTRANSMIT:black:black+h[0m
             [0;7;33;109mDIAG:yellow+i:default+h[0m
             [0;7;35;109mINTERRUPT:magenta+i:default+h[0m
             [0;7;38;5;118mSIGNAL:118+i[0m
             [0;93;40mTEST:yellow+h:black[0m
             DEFAULT:off
             [0;34;107mNOTICE:blue:white+h[0m
             [0;35;105mALERT:magenta:magenta+h[0m
             [0;7;33;44mASSERT:yellow+i:blue[0m
             [0;7;31;107mALARM:red+i:white+h[0m
             [0;34;49mVERBOSE:blue:default[0m
             [0;1;35;41mmagenta+b:red[0m
             [0;7;31;109mred+i:default+h[0m
             [0;7;31;44mred+i:blue[0m
             [0;38;5;11;41m11:red[0m
             [0;7;38;5;11;41m11+i:red[0m
             [0;38;5;11;42m11:green[0m
             [0;1;36;109mcyan+b:default+h[0m
             [0;7;38;5;130m130+i[0m
             [0;7;39;109mdefault+i:default+h[0m
             [0;7;34;103mblue+i:blue+h[0m
             [0;92;40mgreen+h:black[0m
             [0;7;30;103mblack+i:yellow+h[0m
             [0;4;30;103mblack+u:yellow+h[0m
             [0;90;40mblack+h:black[0m
             [0;30;100mblack:black+h[0m
             [0;7;33;109myellow+i:default+h[0m
             [0;7;35;109mmagenta+i:default+h[0m
             [0;7;38;5;118m118+i[0m
             [0;93;40myellow+h:black[0m
             off
             [0;34;107mblue:white+h[0m
             [0;35;105mmagenta:magenta+h[0m
             [0;7;33;44myellow+i:blue[0m
             [0;7;31;107mred+i:white+h[0m
             [0;34;49mblue:default[0m
[0;7;34;103m       0_272[0m [0;1;35;41mFATAL:magenta+b:red[0m
[0;7;34;103m       0_277[0m [0;7;31;109mCRITICAL:red+i:default+h[0m
[0;7;34;103m       0_280[0m [0;7;31;44mEMERGENCY:red+i:blue[0m
[0;7;34;103m       0_282[0m [0;38;5;11;41mERROR:11:red[0m
[0;7;34;103m       0_285[0m [0;7;38;5;11;41mWARNING:11+i:red[0m
[0;7;34;103m       0_288[0m [0;38;5;11;42mATTENTION:11:green[0m
[0;7;34;103m       0_294[0m [0;1;36;109mINFO:cyan+b:default+h[0m
[0;7;34;103m       0_301[0m [0;7;38;5;130mDEBUG:130+i[0m
[0;7;34;103m       0_307[0m [0;7;39;109mTRACE:default+i:default+h[0m
[0;7;34;103m       0_339[0m [0;7;34;103mTIME:blue+i:blue+h[0m
[0;7;34;103m       0_344[0m [0;92;40mMESSAGE:green+h:black[0m
[0;7;34;103m       0_350[0m [0;7;30;103mREAD:black+i:yellow+h[0m
[0;7;34;103m       0_357[0m [0;4;30;103mWRITE:black+u:yellow+h[0m
[0;7;34;103m       0_364[0m [0;90;40mRECEIVE:black+h:black[0m
[0;7;34;103m       0_371[0m [0;30;100mTRANSMIT:black:black+h[0m
[0;7;34;103m       0_379[0m [0;7;33;109mDIAG:yellow+i:default+h[0m
[0;7;34;103m       0_386[0m [0;7;35;109mINTERRUPT:magenta+i:default+h[0m
[0;7;34;103m       0_393[0m [0;7;38;5;118mSIGNAL:118+i[0m
[0;7;34;103m       0_400[0m [0;93;40mTEST:yellow+h:black[0m
[0;7;34;103m       0_407[0m DEFAULT:off
[0;7;34;103m       0_414[0m [0;34;107mNOTICE:blue:white+h[0m
[0;7;34;103m       0_421[0m [0;35;105mALERT:magenta:magenta+h[0m
[0;7;34;103m       0_429[0m [0;7;33;44mASSERT:yellow+i:blue[0m
[0;7;34;103m       0_462[0m [0;7;31;107mALARM:red+i:white+h[0m
[0;7;34;103m       0_469[0m [0;34;49mVERBOSE:blue:default[0m
[0;7;34;103m       0_477[0m [0;1;35;41mmagenta+b:red[0m
[0;7;34;103m       0_479[0m [0;7;31;109mred+i:default+h[0m
[0;7;34;103m       0_482[0m [0;7;31;44mred+i:blue[0m
[0;7;34;103m       0_488[0m [0;38;5;11;41m11:red[0m
[0;7;34;103m       0_494[0m [0;7;38;5;11;41m11+i:red[0m
[0;7;34;103m       0_499[0m [0;38;5;11;42m11:green[0m
[0;7;34;103m       0_506[0m [0;1;36;109mcyan+b:default+h[0m
[0;7;34;103m       0_512[0m [0;7;38;5;130m130+i[0m
[0;7;34;103m       0_518[0m [0;7;39;109mdefault+i:default+h[0m
[0;7;34;103m       0_525[0m [0;7;34;103mblue+i:blue+h[0m
[0;7;34;103m       0_531[0m [0;92;40mgreen+h:black[0m
[0;7;34;103m       0_538[0m [0;7;30;103mblack+i:yellow+h[0m
[0;7;34;103m       0_545[0m [0;4;30;103mblack+u:yellow+h[0m
[0;7;34;103m       0_551[0m [0;90;40mblack+h:black[0m
[0;7;34;103m       0_558[0m [0;30;100mblack:black+h[0m
[0;7;34;103m       0_565[0m [0;7;33;109myellow+i:default+h[0m
[0;7;34;103m       0_572[0m [0;7;35;109mmagenta+i:default+h[0m
[0;7;34;103m       0_579[0m [0;7;38;5;118m118+i[0m
[0;7;34;103m       0_586[0m [0;93;40myellow+h:black[0m
[0;7;34;103m       0_593[0m off
[0;7;34;103m       0_600[0m [0;34;107mblue:white+h[0m
[0;7;34;103m       0_607[0m [0;35;105mmagenta:magenta+h[0m
[0;7;34;103m       0_614[0m [0;7;33;44myellow+i:blue[0m
[0;7;34;103m       0_621[0m [0;7;31;107mred+i:white+h[0m
[0;7;34;103m       0_629[0m [0;34;49mblue:default[0m
[0;7;34;103m       0_636[0m [0;1;35;41mFATAL:magenta+b:red[0m
[0;7;34;103m       0_640[0m [0;7;31;109mCRITICAL:red+i:default+h[0m
[0;7;34;103m       0_643[0m [0;7;31;44mEMERGENCY:red+i:blue[0m
[0;7;34;103m       0_649[0m [0;38;5;11;41mERROR:11:red[0m
[0;7;34;103m       0_652[0m [0;7;38;5;11;41mWARNING:11+i:red[0m
[0;7;34;103m       0_658[0m [0;38;5;11;42mATTENTION:11:green[0m
[0;7;34;103m       0_661[0m [0;1;36;109mINFO:cyan+b:default+h[0m
[0;7;34;103m       0_667[0m [0;7;38;5;130mDEBUG:130+i[0m
[0;7;34;103m       0_674[0m [0;7;39;109mTRACE:default+i:default+h[0m
[0;7;34;103m       0_681[0m [0;7;34;103mTIME:blue+i:blue+h[0m
[0;7;34;103m       0_687[0m [0;92;40mMESSAGE:green+h:black[0m
[0;7;34;103m       0_694[0m [0;7;30;103mREAD:black+i:yellow+h[0m
[0;7;34;103m       0_701[0m [0;4;30;103mWRITE:black+u:yellow+h[0m
[0;7;34;103m       0_708[0m [0;90;40mRECEIVE:black+h:black[0m
[0;7;34;103m       0_714[0m [0;30;100mTRANSMIT:black:black+h[0m
[0;7;34;103m       0_722[0m [0;7;33;109mDIAG:yellow+i:default+h[0m
[0;7;34;103m       0_729[0m [0;7;35;109mINTERRUPT:magenta+i:default+h[0m
[0;7;34;103m       0_736[0m [0;7;38;5;118mSIGNAL:118+i[0m
[0;7;34;103m       0_741[0m [0;93;40mTEST:yellow+h:black[0m
[0;7;34;103m       0_748[0m DEFAULT:off
[0;7;34;103m       0_755[0m [0;34;107mNOTICE:blue:white+h[0m
[0;7;34;103m       0_770[0m [0;35;105mALERT:magenta:magenta+h[0m
[0;7;34;103m       0_777[0m [0;7;33;44mASSERT:yellow+i:blue[0m
[0;7;34;103m       0_784[0m [0;7;31;107mALARM:red+i:white+h[0m
[0;7;34;103m       0_803[0m [0;34;49mVERBOSE:blue:default[0m
[0;7;34;103m       0_809[0m [0;1;35;41mmagenta+b:red[0m
[0;7;34;103m       0_814[0m [0;7;31;109mred+i:default+h[0m
[0;7;34;103m       0_817[0m [0;7;31;44mred+i:blue[0m
[0;7;34;103m       0_819[0m [0;38;5;11;41m11:red[0m
[0;7;34;103m       0_822[0m [0;7;38;5;11;41m11+i:red[0m
[0;7;34;103m       0_828[0m [0;38;5;11;42m11:green[0m
[0;7;34;103m       0_835[0m [0;1;36;109mcyan+b:default+h[0m
[0;7;34;103m       0_841[0m [0;7;38;5;130m130+i[0m
[0;7;34;103m       0_847[0m [0;7;39;109mdefault+i:default+h[0m
[0;7;34;103m       0_854[0m [0;7;34;103mblue+i:blue+h[0m
[0;7;34;103m       0_861[0m [0;92;40mgreen+h:black[0m
[0;7;34;103m       0_865[0m [0;7;30;103mblack+i:yellow+h[0m
[0;7;34;103m       0_872[0m [0;4;30;103mblack+u:yellow+h[0m
[0;7;34;103m       0_878[0m [0;90;40mblack+h:black[0m
[0;7;34;103m       0_883[0m [0;30;100mblack:black+h[0m
[0;7;34;103m       0_890[0m [0;7;33;109myellow+i:default+h[0m
[0;7;34;103m       0_897[0m [0;7;35;109mmagenta+i:default+h[0m
[0;7;34;103m       0_904[0m [0;7;38;5;118m118+i[0m
[0;7;34;103m       0_911[0m [0;93;40myellow+h:black[0m
[0;7;34;103m       0_918[0m off
[0;7;34;103m       0_925[0m [0;34;107mblue:white+h[0m
[0;7;34;103m       0_932[0m [0;35;105mmagenta:magenta+h[0m
[0;7;34;103m       0_940[0m [0;7;33;44myellow+i:blue[0m
[0;7;34;103m       0_947[0m [0;7;31;107mred+i:white+h[0m
[0;7;34;103m       0_954[0m [0;34;49mblue:default[0m
[0;7;34;103m 0:00:00,005[0m [0;1;35;41mFATAL:magenta+b:red[0m
[0;7;34;103m 0:00:00,005[0m [0;7;31;109mCRITICAL:red+i:default+h[0m
[0;7;34;103m 0:00:00,005[0m [0;7;31;44mEMERGENCY:red+i:blue[0m
[0;7;34;103m 0:00:00,005[0m [0;38;5;11;41mERROR:11:red[0m
[0;7;34;103m 0:00:00,005[0m [0;7;38;5;11;41mWARNING:11+i:red[0m
[0;7;34;103m 0:00:00,005[0m [0;38;5;11;42mATTENTION:11:green[0m
[0;7;34;103m 0:00:00,005[0m [0;1;36;109mINFO:cyan+b:default+h[0m
[0;7;34;103m 0:00:00,005[0m [0;7;38;5;130mDEBUG:130+i[0m
[0;7;34;103m 0:00:00,006[0m [0;7;39;109mTRACE:default+i:default+h[0m
[0;7;34;103m 0:00:00,006[0m [0;7;34;103mTIME:blue+i:blue+h[0m
[0;7;34;103m 0:00:00,006[0m [0;92;40mMESSAGE:green+h:black[0m
[0;7;34;103m 0:00:00,006[0m [0;7;30;103mREAD:black+i:yellow+h[0m
[0;7;34;103m 0:00:00,006[0m [0;4;30;103mWRITE:black+u:yellow+h[0m
[0;7;34;103m 0:00:00,006[0m [0;90;40mRECEIVE:black+h:black[0m
[0;7;34;103m 0:00:00,006[0m [0;30;100mTRANSMIT:black:black+h[0m
[0;7;34;103m 0:00:00,006[0m [0;7;33;109mDIAG:yellow+i:default+h[0m
[0;7;34;103m 0:00:00,006[0m [0;7;35;109mINTERRUPT:magenta+i:default+h[0m
[0;7;34;103m 0:00:00,006[0m [0;7;38;5;118mSIGNAL:118+i[0m
[0;7;34;103m 0:00:00,006[0m [0;93;40mTEST:yellow+h:black[0m
[0;7;34;103m 0:00:00,006[0m DEFAULT:off
[0;7;34;103m 0:00:00,006[0m [0;34;107mNOTICE:blue:white+h[0m
[0;7;34;103m 0:00:00,006[0m [0;35;105mALERT:magenta:magenta+h[0m
[0;7;34;103m 0:00:00,006[0m [0;7;33;44mASSERT:yellow+i:blue[0m
[0;7;34;103m 0:00:00,006[0m [0;7;31;107mALARM:red+i:white+h[0m
[0;7;34;103m 0:00:00,006[0m [0;34;49mVERBOSE:blue:default[0m
[0;7;34;103m 0:00:00,006[0m [0;1;35;41mmagenta+b:red[0m
[0;7;34;103m 0:00:00,006[0m [0;7;31;109mred+i:default+h[0m
[0;7;34;103m 0:00:00,006[0m [0;7;31;44mred+i:blue[0m
[0;7;34;103m 0:00:00,006[0m [0;38;5;11;41m11:red[0m
[0;7;34;103m 0:00:00,006[0m [0;7;38;5;11;41m11+i:red[0m
[0;7;34;103m 0:00:00,006[0m [0;38;5;11;42m11:green[0m
[0;7;34;103m 0:00:00,006[0m [0;1;36;109mcyan+b:default+h[0m
[0;7;34;103m 0:00:00,006[0m [0;7;38;5;130m130+i[0m
[0;7;34;103m 0:00:00,006[0m [0;7;39;109mdefault+i:default+h[0m
[0;7;34;103m 0:00:00,006[0m [0;7;34;103mblue+i:blue+h[0m
[0;7;34;103m 0:00:00,006[0m [0;92;40mgreen+h:black[0m
[0;7;34;103m 0:00:00,006[0m [0;7;30;103mblack+i:yellow+h[0m
[0;7;34;103m 0:00:00,006[0m [0;4;30;103mblack+u:yellow+h[0m
[0;7;34;103m 0:00:00,006[0m [0;90;40mblack+h:black[0m
[0;7;34;103m 0:00:00,006[0m [0;30;100mblack:black+h[0m
[0;7;34;103m 0:00:00,006[0m [0;7;33;109myellow+i:default+h[0m
[0;7;34;103m 0:00:00,006[0m [0;7;35;109mmagenta+i:default+h[0m
[0;7;34;103m 0:00:00,006[0m [0;7;38;5;118m118+i[0m
[0;7;34;103m 0:00:00,006[0m [0;93;40myellow+h:black[0m
[0;7;34;103m 0:00:00,006[0m off
[0;7;34;103m 0:00:00,006[0m [0;34;107mblue:white+h[0m
[0;7;34;103m 0:00:00,006[0m [0;35;105mmagenta:magenta+h[0m
[0;7;34;103m 0:00:00,006[0m [0;7;33;44myellow+i:blue[0m
[0;7;34;103m 0:00:00,006[0m [0;7;31;107mred+i:white+h[0m
[0;7;34;103m 0:00:00,006[0m [0;34;49mblue:default[0m
[0;7;34;103m 0:00:00,006[0m [0;1;35;41mFATAL:magenta+b:red[0m
[0;7;34;103m 0:00:00,006[0m [0;7;31;109mCRITICAL:red+i:default+h[0m
[0;7;34;103m 0:00:00,006[0m [0;7;31;44mEMERGENCY:red+i:blue[0m
[0;7;34;103m 0:00:00,006[0m [0;38;5;11;41mERROR:11:red[0m
[0;7;34;103m 0:00:00,006[0m [0;7;38;5;11;41mWARNING:11+i:red[0m
[0;7;34;103m 0:00:00,006[0m [0;38;5;11;42mATTENTION:11:green[0m
[0;7;34;103m 0:00:00,006[0m [0;1;36;109mINFO:cyan+b:default+h[0m
[0;7;34;103m 0:00:00,006[0m [0;7;38;5;130mDEBUG:130+i[0m
[0;7;34;103m 0:00:00,006[0m [0;7;39;109mTRACE:default+i:default+h[0m
[0;7;34;103m 0:00:00,006[0m [0;7;34;103mTIME:blue+i:blue+h[0m
[0;7;34;103m 0:00:00,006[0m [0;92;40mMESSAGE:green+h:black[0m
[0;7;34;103m 0:00:00,006[0m [0;7;30;103mREAD:black+i:yellow+h[0m
[0;7;34;103m 0:00:00,006[0m [0;4;30;103mWRITE:black+u:yellow+h[0m
[0;7;34;103m 0:00:00,006[0m [0;90;40mRECEIVE:black+h:black[0m
[0;7;34;103m 0:00:00,006[0m [0;30;100mTRANSMIT:black:black+h[0m
[0;7;34;103m 0:00:00,006[0m [0;7;33;109mDIAG:yellow+i:default+h[0m
[0;7;34;103m 0:00:00,006[0m [0;7;35;109mINTERRUPT:magenta+i:default+h[0m
[0;7;34;103m 0:00:00,006[0m [0;7;38;5;118mSIGNAL:118+i[0m
[0;7;34;103m 0:00:00,006[0m [0;93;40mTEST:yellow+h:black[0m
[0;7;34;103m 0:00:00,006[0m DEFAULT:off
[0;7;34;103m 0:00:00,006[0m [0;34;107mNOTICE:blue:white+h[0m
[0;7;34;103m 0:00:00,006[0m [0;35;105mALERT:magenta:magenta+h[0m
[0;7;34;103m 0:00:00,006[0m [0;7;33;44mASSERT:yellow+i:blue[0m
[0;7;34;103m 0:00:00,006[0m [0;7;31;107mALARM:red+i:white+h[0m
[0;7;34;103m 0:00:00,006[0m [0;34;49mVERBOSE:blue:default[0m
[0;7;34;103m 0:00:00,006[0m [0;1;35;41mmagenta+b:red[0m
[0;7;34;103m 0:00:00,006[0m [0;7;31;109mred+i:default+h[0m
[0;7;34;103m 0:00:00,006[0m [0;7;31;44mred+i:blue[0m
[0;7;34;103m 0:00:00,006[0m [0;38;5;11;41m11:red[0m
[0;7;34;103m 0:00:00,006[0m [0;7;38;5;11;41m11+i:red[0m
[0;7;34;103m 0:00:00,006[0m [0;38;5;11;42m11:green[0m
[0;7;34;103m 0:00:00,006[0m [0;1;36;109mcyan+b:default+h[0m
[0;7;34;103m 0:00:00,006[0m [0;7;38;5;130m130+i[0m
[0;7;34;103m 0:00:00,006[0m [0;7;39;109mdefault+i:default+h[0m
[0;7;34;103m 0:00:00,006[0m [0;7;34;103mblue+i:blue+h[0m
[0;7;34;103m 0:00:00,006[0m [0;92;40mgreen+h:black[0m
[0;7;34;103m 0:00:00,006[0m [0;7;30;103mblack+i:yellow+h[0m
[0;7;34;103m 0:00:00,006[0m [0;4;30;103mblack+u:yellow+h[0m
[0;7;34;103m 0:00:00,006[0m [0;90;40mblack+h:black[0m
[0;7;34;103m 0:00:00,006[0m [0;30;100mblack:black+h[0m
[0;7;34;103m 0:00:00,006[0m [0;7;33;109myellow+i:default+h[0m
[0;7;34;103m 0:00:00,006[0m [0;7;35;109mmagenta+i:default+h[0m
[0;7;34;103m 0:00:00,006[0m [0;7;38;5;118m118+i[0m
[0;7;34;103m 0:00:00,006[0m [0;93;40myellow+h:black[0m
[0;7;34;103m 0:00:00,006[0m off
[0;7;34;103m 0:00:00,006[0m [0;34;107mblue:white+h[0m
[0;7;34;103m 0:00:00,006[0m [0;35;105mmagenta:magenta+h[0m
[0;7;34;103m 0:00:00,006[0m [0;7;33;44myellow+i:blue[0m
[0;7;34;103m 0:00:00,006[0m [0;7;31;107mred+i:white+h[0m
[0;7;34;103m 0:00:00,006[0m [0;34;49mblue:default[0m
             [0;92;40m-1 (%d)[0m
             [0;7;38;5;118mTRICE8 with 1 to 12 values[0m
             [0;7;30;103mTRICE -1[0m
             [0;7;30;103mTRICE -1, -2[0m
             [0;7;30;103mTRICE -1, -2, -3[0m
             [0;7;30;103mTRICE -1, -2, -3, -4[0m
             [0;7;30;103mTRICE -1, -2, -3, -4, -5[0m
             [0;7;30;103mTRICE -1, -2, -3, -4, -5, -6[0m
             [0;7;30;103mTRICE -1, -2, -3, -4, -5, -6, -7[0m
             [0;7;30;103mTRICE -1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;7;30;103mTRICE -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
             [0;7;30;103mTRICE -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
             [0;7;30;103mTRICE -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;7;30;103mTRICE -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
             [0;7;30;103mTRICE -1[0m
             [0;7;30;103mTRICE -1, -2[0m
             [0;7;30;103mTRICE -1, -2, -3[0m
             [0;7;30;103mTRICE -1, -2, -3, -4[0m
             [0;7;30;103mTRICE -1, -2, -3, -4, -5[0m
             [0;7;30;103mTRICE -1, -2, -3, -4, -5, -6[0m
             [0;7;30;103mTRICE -1, -2, -3, -4, -5, -6, -7[0m
             [0;7;30;103mTRICE -1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;7;30;103mTRICE -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
             [0;7;30;103mTRICE -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
             [0;7;30;103mTRICE -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;7;30;103mTRICE -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
             [0;7;30;103mTRICE -1[0m
             [0;7;30;103mTRICE -1, -2[0m
             [0;7;30;103mTRICE -1, -2, -3[0m
             [0;7;30;103mTRICE -1, -2, -3, -4[0m
             [0;7;30;103mTRICE -1, -2, -3, -4, -5[0m
             [0;7;30;103mTRICE -1, -2, -3, -4, -5, -6[0m
             [0;7;30;103mTRICE -1, -2, -3, -4, -5, -6, -7[0m
             [0;7;30;103mTRICE -1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;7;30;103mTRICE -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
             [0;7;30;103mTRICE -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
             [0;7;30;103mTRICE -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;7;30;103mTRICE -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
             [0;7;38;5;118mTRICE_n with 1 to 12 values[0m
             [0;7;30;103mTRICE_1  -1[0m
             [0;7;30;103mTRICE_2  -1, -2[0m
             [0;7;30;103mTRICE_3  -1, -2, -3[0m
             [0;7;30;103mTRICE_4  -1, -2, -3, -4[0m
             [0;7;30;103mTRICE_5  -1, -2, -3, -4, -5[0m
             [0;7;30;103mTRICE_6  -1, -2, -3, -4, -5, -6[0m
             [0;7;30;103mTRICE_7  -1, -2, -3, -4, -5, -6, -7[0m
             [0;7;30;103mTRICE_8  -1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;7;30;103mTRICE_9  -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
             [0;7;30;103mTRICE_10 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
             [0;7;30;103mTRICE_11 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;7;30;103mTRICE_12 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m       0_090[0m [0;7;30;103mTRICE_1  -1[0m
[0;7;34;103m       0_094[0m [0;7;30;103mTRICE_2  -1, -2[0m
[0;7;34;103m       0_098[0m [0;7;30;103mTRICE_3  -1, -2, -3[0m
[0;7;34;103m       0_102[0m [0;7;30;103mTRICE_4  -1, -2, -3, -4[0m
[0;7;34;103m       0_106[0m [0;7;30;103mTRICE_5  -1, -2, -3, -4, -5[0m
[0;7;34;103m       0_113[0m [0;7;30;103mTRICE_6  -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m       0_120[0m [0;7;30;103mTRICE_7  -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m       0_127[0m [0;7;30;103mTRICE_8  -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m       0_134[0m [0;7;30;103mTRICE_9  -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m       0_141[0m [0;7;30;103mTRICE_10 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m       0_148[0m [0;7;30;103mTRICE_11 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m       0_156[0m [0;7;30;103mTRICE_12 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE_1  -1[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE_2  -1, -2[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE_3  -1, -2, -3[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE_4  -1, -2, -3, -4[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE_5  -1, -2, -3, -4, -5[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE_6  -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE_7  -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE_8  -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE_9  -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE_10 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE_11 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE_12 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m 0:00:00,007[0m [0;7;38;5;118mtrice_n with 1 to 12 values[0m
             [0;7;30;103mtrice_1  -1[0m
             [0;7;30;103mtrice_2  -1, -2[0m
             [0;7;30;103mtrice_3  -1, -2, -3[0m
             [0;7;30;103mtrice_4  -1, -2, -3, -4[0m
             [0;7;30;103mtrice_5  -1, -2, -3, -4, -5[0m
             [0;7;30;103mtrice_6  -1, -2, -3, -4, -5, -6[0m
             [0;7;30;103mtrice_7  -1, -2, -3, -4, -5, -6, -7[0m
             [0;7;30;103mtrice_8  -1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;7;30;103mtrice_9  -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
             [0;7;30;103mtrice_10 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
             [0;7;30;103mtrice_11 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;7;30;103mtrice_12 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m       0_353[0m [0;7;30;103mTrice_1  -1[0m
[0;7;34;103m       0_357[0m [0;7;30;103mTrice_2  -1, -2[0m
[0;7;34;103m       0_363[0m [0;7;30;103mTrice_3  -1, -2, -3[0m
[0;7;34;103m       0_369[0m [0;7;30;103mTrice_4  -1, -2, -3, -4[0m
[0;7;34;103m       0_373[0m [0;7;30;103mTrice_5  -1, -2, -3, -4, -5[0m
[0;7;34;103m       0_380[0m [0;7;30;103mTrice_6  -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m       0_385[0m [0;7;30;103mTrice_7  -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m       0_390[0m [0;7;30;103mTrice_8  -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m       0_395[0m [0;7;30;103mTrice_9  -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m       0_403[0m [0;7;30;103mTrice_10 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m       0_408[0m [0;7;30;103mTrice_11 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m       0_416[0m [0;7;30;103mTrice_12 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRice_1  -1[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRice_2  -1, -2[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRice_3  -1, -2, -3[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRice_4  -1, -2, -3, -4[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRice_5  -1, -2, -3, -4, -5[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRice_6  -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRice_7  -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRice_8  -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRice_9  -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRice_10 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRice_11 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRice_12 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
             [0;7;38;5;118mTRICE8 with 1 to 12 values[0m
             [0;7;30;103mTRICE8 -1[0m
             [0;7;30;103mTRICE8 -1, -2[0m
             [0;7;30;103mTRICE8 -1, -2, -3[0m
             [0;7;30;103mTRICE8 -1, -2, -3, -4[0m
             [0;7;30;103mTRICE8 -1, -2, -3, -4, -5[0m
             [0;7;30;103mTRICE8 -1, -2, -3, -4, -5, -6[0m
             [0;7;30;103mTRICE8 -1, -2, -3, -4, -5, -6, -7[0m
             [0;7;30;103mTRICE8 -1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;7;30;103mTRICE8 -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
             [0;7;30;103mTRICE8 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
             [0;7;30;103mTRICE8 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;7;30;103mTRICE8 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m       0_591[0m [0;7;30;103mTRICE8 -1[0m
[0;7;34;103m       0_597[0m [0;7;30;103mTRICE8 -1, -2[0m
[0;7;34;103m       0_604[0m [0;7;30;103mTRICE8 -1, -2, -3[0m
[0;7;34;103m       0_610[0m [0;7;30;103mTRICE8 -1, -2, -3, -4[0m
[0;7;34;103m       0_616[0m [0;7;30;103mTRICE8 -1, -2, -3, -4, -5[0m
[0;7;34;103m       0_623[0m [0;7;30;103mTRICE8 -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m       0_628[0m [0;7;30;103mTRICE8 -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m       0_635[0m [0;7;30;103mTRICE8 -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m       0_640[0m [0;7;30;103mTRICE8 -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m       0_645[0m [0;7;30;103mTRICE8 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m       0_652[0m [0;7;30;103mTRICE8 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m       0_660[0m [0;7;30;103mTRICE8 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE8 -1[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE8 -1, -2[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE8 -1, -2, -3[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE8 -1, -2, -3, -4[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE8 -1, -2, -3, -4, -5[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE8 -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE8 -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE8 -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE8 -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE8 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE8 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE8 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
             [0;7;38;5;118mTRICE8_n with 1 to 12 values[0m
             [0;7;30;103mTRICE8_1  -1[0m
             [0;7;30;103mTRICE8_2  -1, -2[0m
             [0;7;30;103mTRICE8_3  -1, -2, -3[0m
             [0;7;30;103mTRICE8_4  -1, -2, -3, -4[0m
             [0;7;30;103mTRICE8_5  -1, -2, -3, -4, -5[0m
             [0;7;30;103mTRICE8_6  -1, -2, -3, -4, -5, -6[0m
             [0;7;30;103mTRICE8_7  -1, -2, -3, -4, -5, -6, -7[0m
             [0;7;30;103mTRICE8_8  -1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;7;30;103mTRICE8_9  -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
             [0;7;30;103mTRICE8_10 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
             [0;7;30;103mTRICE8_11 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;7;30;103mTRICE8_12 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m       0_856[0m [0;7;30;103mTRICE8_1  -1[0m
[0;7;34;103m       0_862[0m [0;7;30;103mTRICE8_2  -1, -2[0m
[0;7;34;103m       0_868[0m [0;7;30;103mTRICE8_3  -1, -2, -3[0m
[0;7;34;103m       0_873[0m [0;7;30;103mTRICE8_4  -1, -2, -3, -4[0m
[0;7;34;103m       0_879[0m [0;7;30;103mTRICE8_5  -1, -2, -3, -4, -5[0m
[0;7;34;103m       0_884[0m [0;7;30;103mTRICE8_6  -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m       0_891[0m [0;7;30;103mTRICE8_7  -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m       0_898[0m [0;7;30;103mTRICE8_8  -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m       0_905[0m [0;7;30;103mTRICE8_9  -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m       0_913[0m [0;7;30;103mTRICE8_10 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m       0_920[0m [0;7;30;103mTRICE8_11 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m       0_928[0m [0;7;30;103mTRICE8_12 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE8_1  -1[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE8_2  -1, -2[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE8_3  -1, -2, -3[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE8_4  -1, -2, -3, -4[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE8_5  -1, -2, -3, -4, -5[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE8_6  -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE8_7  -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE8_8  -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m 0:00:00,007[0m [0;7;30;103mTRICE8_9  -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m 0:00:00,008[0m [0;7;30;103mTRICE8_10 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m 0:00:00,008[0m [0;7;30;103mTRICE8_11 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m 0:00:00,008[0m [0;7;30;103mTRICE8_12 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
             [0;7;38;5;118mtrice8 with 1 to 12 values[0m
             [0;7;30;103mtrice8 -1[0m
             [0;7;30;103mtrice8 -1, -2[0m
             [0;7;30;103mtrice8 -1, -2, -3[0m
             [0;7;30;103mtrice8 -1, -2, -3, -4[0m
             [0;7;30;103mtrice8 -1, -2, -3, -4, -5[0m
             [0;7;30;103mtrice8 -1, -2, -3, -4, -5, -6[0m
             [0;7;30;103mtrice8 -1, -2, -3, -4, -5, -6, -7[0m
             [0;7;30;103mtrice8 -1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;7;30;103mtrice8 -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
             [0;7;30;103mtrice8 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
             [0;7;30;103mtrice8 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;7;30;103mtrice8 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m       0_131[0m [0;7;30;103mTrice8 -1[0m
[0;7;34;103m       0_137[0m [0;7;30;103mTrice8 -1, -2[0m
[0;7;34;103m       0_143[0m [0;7;30;103mTrice8 -1, -2, -3[0m
[0;7;34;103m       0_150[0m [0;7;30;103mTrice8 -1, -2, -3, -4[0m
[0;7;34;103m       0_156[0m [0;7;30;103mTrice8 -1, -2, -3, -4, -5[0m
[0;7;34;103m       0_163[0m [0;7;30;103mTrice8 -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m       0_171[0m [0;7;30;103mTrice8 -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m       0_178[0m [0;7;30;103mTrice8 -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m       0_185[0m [0;7;30;103mTrice8 -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m       0_190[0m [0;7;30;103mTrice8 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m       0_198[0m [0;7;30;103mTrice8 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m       0_206[0m [0;7;30;103mTrice8 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m 0:00:00,008[0m [0;7;30;103mTRice8 -1[0m
[0;7;34;103m 0:00:00,008[0m [0;7;30;103mTRice8 -1, -2[0m
[0;7;34;103m 0:00:00,008[0m [0;7;30;103mTRice8 -1, -2, -3[0m
[0;7;34;103m 0:00:00,008[0m [0;7;30;103mTRice8 -1, -2, -3, -4[0m
[0;7;34;103m 0:00:00,008[0m [0;7;30;103mTRice8 -1, -2, -3, -4, -5[0m
[0;7;34;103m 0:00:00,008[0m [0;7;30;103mTRice8 -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m 0:00:00,008[0m [0;7;30;103mTRice8 -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m 0:00:00,008[0m [0;7;30;103mTRice8 -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m 0:00:00,008[0m [0;7;30;103mTRice8 -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m 0:00:00,008[0m [0;7;30;103mTRice8 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m 0:00:00,008[0m [0;7;30;103mTRice8 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m 0:00:00,008[0m [0;7;30;103mTRice8 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m 0:00:00,008[0m [0;7;38;5;118mtrice8_n with 1 to 12 values[0m
             [0;7;30;103mtrice8_1  -1[0m
             [0;7;30;103mtrice8_2  -1, -2[0m
             [0;7;30;103mtrice8_3  -1, -2, -3[0m
             [0;7;30;103mtrice8_4  -1, -2, -3, -4[0m
             [0;7;30;103mtrice8_5  -1, -2, -3, -4, -5[0m
             [0;7;30;103mtrice8_6  -1, -2, -3, -4, -5, -6[0m
             [0;7;30;103mtrice8_7  -1, -2, -3, -4, -5, -6, -7[0m
             [0;7;30;103mtrice8_8  -1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;7;30;103mtrice8_9  -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
             [0;7;30;103mtrice8_10 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
             [0;7;30;103mtrice8_11 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;7;30;103mtrice8_12 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m       0_390[0m [0;7;30;103mTrice8_1  -1[0m
[0;7;34;103m       0_394[0m [0;7;30;103mTrice8_2  -1, -2[0m
[0;7;34;103m       0_401[0m [0;7;30;103mTrice8_3  -1, -2, -3[0m
[0;7;34;103m       0_407[0m [0;7;30;103mTrice8_4  -1, -2, -3, -4[0m
[0;7;34;103m       0_412[0m [0;7;30;103mTrice8_5  -1, -2, -3, -4, -5[0m
[0;7;34;103m       0_419[0m [0;7;30;103mTrice8_6  -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m       0_425[0m [0;7;30;103mTrice8_7  -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m       0_432[0m [0;7;30;103mTrice8_8  -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m       0_440[0m [0;7;30;103mTrice8_9  -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m       0_445[0m [0;7;30;103mTrice8_10 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m       0_451[0m [0;7;30;103mTrice8_11 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m       0_457[0m [0;7;30;103mTrice8_12 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m 0:00:00,008[0m [0;7;30;103mTRice8_1  -1[0m
[0;7;34;103m 0:00:00,008[0m [0;7;30;103mTRice8_2  -1, -2[0m
[0;7;34;103m 0:00:00,008[0m [0;7;30;103mTRice8_3  -1, -2, -3[0m
[0;7;34;103m 0:00:00,008[0m [0;7;30;103mTRice8_4  -1, -2, -3, -4[0m
[0;7;34;103m 0:00:00,008[0m [0;7;30;103mTRice8_5  -1, -2, -3, -4, -5[0m
[0;7;34;103m 0:00:00,008[0m [0;7;30;103mTRice8_6  -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m 0:00:00,008[0m [0;7;30;103mTRice8_7  -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m 0:00:00,008[0m [0;7;30;103mTRice8_8  -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m 0:00:00,008[0m [0;7;30;103mTRice8_9  -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m 0:00:00,008[0m [0;7;30;103mTRice8_10 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m 0:00:00,008[0m [0;7;30;103mTRice8_11 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m 0:00:00,008[0m [0;7;30;103mTRice8_12 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
             [0;7;38;5;118mTRICE16 with 1 to 12 values (line 1755)[0m
             [0;7;30;103mTRICE16 -1[0m
             [0;7;30;103mTRICE16 -1, -2[0m
             [0;7;30;103mTRICE16 -1, -2, -3[0m
             [0;7;30;103mTRICE16 -1, -2, -3, -4[0m
             [0;7;30;103mTRICE16 -1, -2, -3, -4, -5[0m
             [0;7;30;103mTRICE16 -1, -2, -3, -4, -5, -6[0m
             [0;7;30;103mTRICE16 -1, -2, -3, -4, -5, -6, -7[0m
             [0;7;30;103mTRICE16 -1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;7;30;103mTRICE16 -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
             [0;7;30;103mTRICE16 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
             [0;7;30;103mTRICE16 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;7;30;103mTRICE16 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
             [0;7;30;103mTRICE16 -1[0m
             [0;7;30;103mTRICE16 -1, -2[0m
             [0;7;30;103mTRICE16 -1, -2, -3[0m
             [0;7;30;103mTRICE16 -1, -2, -3, -4[0m
             [0;7;30;103mTRICE16 -1, -2, -3, -4, -5[0m
             [0;7;30;103mTRICE16 -1, -2, -3, -4, -5, -6[0m
             [0;7;30;103mTRICE16 -1, -2, -3, -4, -5, -6, -7[0m
             [0;7;30;103mTRICE16 -1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;7;30;103mTRICE16 -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
             [0;7;30;103mTRICE16 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
             [0;7;30;103mTRICE16 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;7;30;103mTRICE16 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
             [0;7;30;103mTRICE16 -1[0m
             [0;7;30;103mTRICE16 -1, -2[0m
             [0;7;30;103mTRICE16 -1, -2, -3[0m
             [0;7;30;103mTRICE16 -1, -2, -3, -4[0m
             [0;7;30;103mTRICE16 -1, -2, -3, -4, -5[0m
             [0;7;30;103mTRICE16 -1, -2, -3, -4, -5, -6[0m
             [0;7;30;103mTRICE16 -1, -2, -3, -4, -5, -6, -7[0m
             [0;7;30;103mTRICE16 -1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;7;30;103mTRICE16 -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
             [0;7;30;103mTRICE16 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
             [0;7;30;103mTRICE16 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;7;30;103mTRICE16 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
             [0;7;38;5;118mTRICE16_n with 1 to 12 values (line 1793)[0m
             [0;7;30;103mTRICE16_1  -1[0m
             [0;7;30;103mTRICE16_2  -1, -2[0m
             [0;7;30;103mTRICE16_3  -1, -2, -3[0m
             [0;7;30;103mTRICE16_4  -1, -2, -3, -4[0m
             [0;7;30;103mTRICE16_5  -1, -2, -3, -4, -5[0m
             [0;7;30;103mTRICE16_6  -1, -2, -3, -4, -5, -6[0m
             [0;7;30;103mTRICE16_7  -1, -2, -3, -4, -5, -6, -7[0m
             [0;7;30;103mTRICE16_8  -1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;7;30;103mTRICE16_9  -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
             [0;7;30;103mTRICE16_10 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
             [0;7;30;103mTRICE16_11 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;7;30;103mTRICE16_12 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m       0_883[0m [0;7;30;103mTRICE16_1  -1[0m
[0;7;34;103m       0_887[0m [0;7;30;103mTRICE16_2  -1, -2[0m
[0;7;34;103m       0_894[0m [0;7;30;103mTRICE16_3  -1, -2, -3[0m
[0;7;34;103m       0_900[0m [0;7;30;103mTRICE16_4  -1, -2, -3, -4[0m
[0;7;34;103m       0_907[0m [0;7;30;103mTRICE16_5  -1, -2, -3, -4, -5[0m
[0;7;34;103m       0_914[0m [0;7;30;103mTRICE16_6  -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m       0_921[0m [0;7;30;103mTRICE16_7  -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m       0_929[0m [0;7;30;103mTRICE16_8  -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m       0_936[0m [0;7;30;103mTRICE16_9  -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m       0_942[0m [0;7;30;103mTRICE16_10 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m       0_947[0m [0;7;30;103mTRICE16_11 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m       0_956[0m [0;7;30;103mTRICE16_12 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m 0:00:00,008[0m [0;7;30;103mTRICE16_1  -1[0m
[0;7;34;103m 0:00:00,008[0m [0;7;30;103mTRICE16_2  -1, -2[0m
[0;7;34;103m 0:00:00,008[0m [0;7;30;103mTRICE16_3  -1, -2, -3[0m
[0;7;34;103m 0:00:00,008[0m [0;7;30;103mTRICE16_4  -1, -2, -3, -4[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRICE16_5  -1, -2, -3, -4, -5[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRICE16_6  -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRICE16_7  -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRICE16_8  -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRICE16_9  -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRICE16_10 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRICE16_11 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRICE16_12 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
             [0;7;38;5;118mtrice16 with 1 to 12 values (line 1831)[0m
             [0;7;30;103mtrice16 -1[0m
             [0;7;30;103mtrice16 -1, -2[0m
             [0;7;30;103mtrice16 -1, -2, -3[0m
             [0;7;30;103mtrice16 -1, -2, -3, -4[0m
             [0;7;30;103mtrice16 -1, -2, -3, -4, -5[0m
             [0;7;30;103mtrice16 -1, -2, -3, -4, -5, -6[0m
             [0;7;30;103mtrice16 -1, -2, -3, -4, -5, -6, -7[0m
             [0;7;30;103mtrice16 -1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;7;30;103mtrice16 -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
             [0;7;30;103mtrice16 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
             [0;7;30;103mtrice16 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;7;30;103mtrice16 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m       0_172[0m [0;7;30;103mTrice16 -1[0m
[0;7;34;103m       0_178[0m [0;7;30;103mTrice16 -1, -2[0m
[0;7;34;103m       0_185[0m [0;7;30;103mTrice16 -1, -2, -3[0m
[0;7;34;103m       0_191[0m [0;7;30;103mTrice16 -1, -2, -3, -4[0m
[0;7;34;103m       0_198[0m [0;7;30;103mTrice16 -1, -2, -3, -4, -5[0m
[0;7;34;103m       0_205[0m [0;7;30;103mTrice16 -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m       0_213[0m [0;7;30;103mTrice16 -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m       0_220[0m [0;7;30;103mTrice16 -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m       0_228[0m [0;7;30;103mTrice16 -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m       0_235[0m [0;7;30;103mTrice16 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m       0_243[0m [0;7;30;103mTrice16 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m       0_251[0m [0;7;30;103mTrice16 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRice16 -1[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRice16 -1, -2[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRice16 -1, -2, -3[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRice16 -1, -2, -3, -4[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRice16 -1, -2, -3, -4, -5[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRice16 -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRice16 -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRice16 -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRice16 -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRice16 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRice16 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRice16 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
             [0;7;38;5;118mtrice16_n with 1 to 12 values (line 1869)[0m
             [0;7;30;103mtrice16_1  -1[0m
             [0;7;30;103mtrice16_2  -1, -2[0m
             [0;7;30;103mtrice16_3  -1, -2, -3[0m
             [0;7;30;103mtrice16_4  -1, -2, -3, -4[0m
             [0;7;30;103mtrice16_5  -1, -2, -3, -4, -5[0m
             [0;7;30;103mtrice16_6  -1, -2, -3, -4, -5, -6[0m
             [0;7;30;103mtrice16_7  -1, -2, -3, -4, -5, -6, -7[0m
             [0;7;30;103mtrice16_8  -1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;7;30;103mtrice16_9  -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
             [0;7;30;103mtrice16_10 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
             [0;7;30;103mtrice16_11 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;7;30;103mtrice16_12 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m       0_432[0m [0;7;30;103mTrice16_1  -1[0m
[0;7;34;103m       0_439[0m [0;7;30;103mTrice16_2  -1, -2[0m
[0;7;34;103m       0_443[0m [0;7;30;103mTrice16_3  -1, -2, -3[0m
[0;7;34;103m       0_448[0m [0;7;30;103mTrice16_4  -1, -2, -3, -4[0m
[0;7;34;103m       0_455[0m [0;7;30;103mTrice16_5  -1, -2, -3, -4, -5[0m
[0;7;34;103m       0_462[0m [0;7;30;103mTrice16_6  -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m       0_469[0m [0;7;30;103mTrice16_7  -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m       0_477[0m [0;7;30;103mTrice16_8  -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m       0_484[0m [0;7;30;103mTrice16_9  -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m       0_492[0m [0;7;30;103mTrice16_10 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m       0_499[0m [0;7;30;103mTrice16_11 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m       0_507[0m [0;7;30;103mTrice16_12 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRice16_1  -1[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRice16_2  -1, -2[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRice16_3  -1, -2, -3[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRice16_4  -1, -2, -3, -4[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRice16_5  -1, -2, -3, -4, -5[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRice16_6  -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRice16_7  -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRice16_8  -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRice16_9  -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRice16_10 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRice16_11 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRice16_12 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
             [0;7;38;5;118mTRICE32 with 1 to 12 values (line 1907)[0m
             [0;7;30;103mTRICE32 -1[0m
             [0;7;30;103mTRICE32 -1, -2[0m
             [0;7;30;103mTRICE32 -1, -2, -3[0m
             [0;7;30;103mTRICE32 -1, -2, -3, -4[0m
             [0;7;30;103mTRICE32 -1, -2, -3, -4, -5[0m
             [0;7;30;103mTRICE32 -1, -2, -3, -4, -5, -6[0m
             [0;7;30;103mTRICE32 -1, -2, -3, -4, -5, -6, -7[0m
             [0;7;30;103mTRICE32 -1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;7;30;103mTRICE32 -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
             [0;7;30;103mTRICE32 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
             [0;7;30;103mTRICE32 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;7;30;103mTRICE32 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m       0_692[0m [0;7;30;103mTRICE32 -1[0m
[0;7;34;103m       0_698[0m [0;7;30;103mTRICE32 -1, -2[0m
[0;7;34;103m       0_705[0m [0;7;30;103mTRICE32 -1, -2, -3[0m
[0;7;34;103m       0_727[0m [0;7;30;103mTRICE32 -1, -2, -3, -4[0m
[0;7;34;103m       0_734[0m [0;7;30;103mTRICE32 -1, -2, -3, -4, -5[0m
[0;7;34;103m       0_741[0m [0;7;30;103mTRICE32 -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m       0_747[0m [0;7;30;103mTRICE32 -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m       0_754[0m [0;7;30;103mTRICE32 -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m       0_759[0m [0;7;30;103mTRICE32 -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m       0_767[0m [0;7;30;103mTRICE32 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m       0_775[0m [0;7;30;103mTRICE32 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m       0_783[0m [0;7;30;103mTRICE32 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRICE32 -1[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRICE32 -1, -2[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRICE32 -1, -2, -3[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRICE32 -1, -2, -3, -4[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRICE32 -1, -2, -3, -4, -5[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRICE32 -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRICE32 -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRICE32 -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRICE32 -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRICE32 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRICE32 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m 0:00:00,009[0m [0;7;30;103mTRICE32 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
             [0;7;38;5;118mTRICE32_n with 1 to 12 values (line 1945)[0m
             [0;7;30;103mTRICE32_1  -1[0m
             [0;7;30;103mTRICE32_2  -1, -2[0m
             [0;7;30;103mTRICE32_3  -1, -2, -3[0m
             [0;7;30;103mTRICE32_4  -1, -2, -3, -4[0m
             [0;7;30;103mTRICE32_5  -1, -2, -3, -4, -5[0m
             [0;7;30;103mTRICE32_6  -1, -2, -3, -4, -5, -6[0m
             [0;7;30;103mTRICE32_7  -1, -2, -3, -4, -5, -6, -7[0m
             [0;7;30;103mTRICE32_8  -1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;7;30;103mTRICE32_9  -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
             [0;7;30;103mTRICE32_10 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
             [0;7;30;103mTRICE32_11 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;7;30;103mTRICE32_12 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m       0_996[0m [0;7;30;103mTRICE32_1  -1[0m
[0;7;34;103m       0_003[0m [0;7;30;103mTRICE32_2  -1, -2[0m
[0;7;34;103m       0_009[0m [0;7;30;103mTRICE32_3  -1, -2, -3[0m
[0;7;34;103m       0_014[0m [0;7;30;103mTRICE32_4  -1, -2, -3, -4[0m
[0;7;34;103m       0_022[0m [0;7;30;103mTRICE32_5  -1, -2, -3, -4, -5[0m
[0;7;34;103m       0_029[0m [0;7;30;103mTRICE32_6  -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m       0_036[0m [0;7;30;103mTRICE32_7  -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m       0_044[0m [0;7;30;103mTRICE32_8  -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m       0_052[0m [0;7;30;103mTRICE32_9  -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m       0_057[0m [0;7;30;103mTRICE32_10 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m       0_064[0m [0;7;30;103mTRICE32_11 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m       0_072[0m [0;7;30;103mTRICE32_12 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRICE32_1  -1[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRICE32_2  -1, -2[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRICE32_3  -1, -2, -3[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRICE32_4  -1, -2, -3, -4[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRICE32_5  -1, -2, -3, -4, -5[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRICE32_6  -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRICE32_7  -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRICE32_8  -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRICE32_9  -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRICE32_10 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRICE32_11 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRICE32_12 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
             [0;7;38;5;118mtrice32 with 1 to 12 values (line 1983)[0m
             [0;7;30;103mtrice32 -1[0m
             [0;7;30;103mtrice32 -1, -2[0m
             [0;7;30;103mtrice32 -1, -2, -3[0m
             [0;7;30;103mtrice32 -1, -2, -3, -4[0m
             [0;7;30;103mtrice32 -1, -2, -3, -4, -5[0m
             [0;7;30;103mtrice32 -1, -2, -3, -4, -5, -6[0m
             [0;7;30;103mtrice32 -1, -2, -3, -4, -5, -6, -7[0m
             [0;7;30;103mtrice32 -1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;7;30;103mtrice32 -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
             [0;7;30;103mtrice32 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
             [0;7;30;103mtrice32 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;7;30;103mtrice32 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m       0_261[0m [0;7;30;103mTrice32 -1[0m
[0;7;34;103m       0_266[0m [0;7;30;103mTrice32 -1, -2[0m
[0;7;34;103m       0_271[0m [0;7;30;103mTrice32 -1, -2, -3[0m
[0;7;34;103m       0_276[0m [0;7;30;103mTrice32 -1, -2, -3, -4[0m
[0;7;34;103m       0_283[0m [0;7;30;103mTrice32 -1, -2, -3, -4, -5[0m
[0;7;34;103m       0_290[0m [0;7;30;103mTrice32 -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m       0_295[0m [0;7;30;103mTrice32 -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m       0_303[0m [0;7;30;103mTrice32 -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m       0_311[0m [0;7;30;103mTrice32 -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m       0_318[0m [0;7;30;103mTrice32 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m       0_326[0m [0;7;30;103mTrice32 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m       0_339[0m [0;7;30;103mTrice32 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRice32 -1[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRice32 -1, -2[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRice32 -1, -2, -3[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRice32 -1, -2, -3, -4[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRice32 -1, -2, -3, -4, -5[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRice32 -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRice32 -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRice32 -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRice32 -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRice32 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRice32 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRice32 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
             [0;7;38;5;118mtrice32_n with 1 to 12 values (line 2021)[0m
             [0;7;30;103mtrice32_1  -1[0m
             [0;7;30;103mtrice32_2  -1, -2[0m
             [0;7;30;103mtrice32_3  -1, -2, -3[0m
             [0;7;30;103mtrice32_4  -1, -2, -3, -4[0m
             [0;7;30;103mtrice32_5  -1, -2, -3, -4, -5[0m
             [0;7;30;103mtrice32_6  -1, -2, -3, -4, -5, -6[0m
             [0;7;30;103mtrice32_7  -1, -2, -3, -4, -5, -6, -7[0m
             [0;7;30;103mtrice32_8  -1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;7;30;103mtrice32_9  -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
             [0;7;30;103mtrice32_10 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
             [0;7;30;103mtrice32_11 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;7;30;103mtrice32_12 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m       0_526[0m [0;7;30;103mTrice32_1  -1[0m
[0;7;34;103m       0_533[0m [0;7;30;103mTrice32_2  -1, -2[0m
[0;7;34;103m       0_540[0m [0;7;30;103mTrice32_3  -1, -2, -3[0m
[0;7;34;103m       0_547[0m [0;7;30;103mTrice32_4  -1, -2, -3, -4[0m
[0;7;34;103m       0_554[0m [0;7;30;103mTrice32_5  -1, -2, -3, -4, -5[0m
[0;7;34;103m       0_561[0m [0;7;30;103mTrice32_6  -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m       0_568[0m [0;7;30;103mTrice32_7  -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m       0_576[0m [0;7;30;103mTrice32_8  -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m       0_584[0m [0;7;30;103mTrice32_9  -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m       0_592[0m [0;7;30;103mTrice32_10 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m       0_600[0m [0;7;30;103mTrice32_11 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m       0_608[0m [0;7;30;103mTrice32_12 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRice32_1  -1[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRice32_2  -1, -2[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRice32_3  -1, -2, -3[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRice32_4  -1, -2, -3, -4[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRice32_5  -1, -2, -3, -4, -5[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRice32_6  -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRice32_7  -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRice32_8  -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRice32_9  -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRice32_10 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRice32_11 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRice32_12 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
             [0;7;38;5;118mTRICE64 with 1 to 12 values (line 2060)[0m
             [0;7;30;103mTRICE64 -1[0m
             [0;7;30;103mTRICE64 -1, -2[0m
             [0;7;30;103mTRICE64 -1, -2, -3[0m
             [0;7;30;103mTRICE64 -1, -2, -3, -4[0m
             [0;7;30;103mTRICE64 -1, -2, -3, -4, -5[0m
             [0;7;30;103mTRICE64 -1, -2, -3, -4, -5, -6[0m
             [0;7;30;103mTRICE64 -1, -2, -3, -4, -5, -6, -7[0m
             [0;7;30;103mTRICE64 -1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;7;30;103mTRICE64 -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
             [0;7;30;103mTRICE64 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
             [0;7;30;103mTRICE64 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;7;30;103mTRICE64 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m       0_797[0m [0;7;30;103mTRICE64 -1[0m
[0;7;34;103m       0_804[0m [0;7;30;103mTRICE64 -1, -2[0m
[0;7;34;103m       0_808[0m [0;7;30;103mTRICE64 -1, -2, -3[0m
[0;7;34;103m       0_815[0m [0;7;30;103mTRICE64 -1, -2, -3, -4[0m
[0;7;34;103m       0_823[0m [0;7;30;103mTRICE64 -1, -2, -3, -4, -5[0m
[0;7;34;103m       0_830[0m [0;7;30;103mTRICE64 -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m       0_853[0m [0;7;30;103mTRICE64 -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m       0_861[0m [0;7;30;103mTRICE64 -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m       0_867[0m [0;7;30;103mTRICE64 -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m       0_875[0m [0;7;30;103mTRICE64 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m       0_883[0m [0;7;30;103mTRICE64 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m       0_892[0m [0;7;30;103mTRICE64 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRICE64 -1[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRICE64 -1, -2[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRICE64 -1, -2, -3[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRICE64 -1, -2, -3, -4[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRICE64 -1, -2, -3, -4, -5[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRICE64 -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRICE64 -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRICE64 -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRICE64 -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRICE64 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRICE64 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m 0:00:00,010[0m [0;7;30;103mTRICE64 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
             [0;7;38;5;118mTRICE64_n with 1 to 12 values (line 2098)[0m
             [0;7;30;103mTRICE64_1  -1[0m
             [0;7;30;103mTRICE64_2  -1, -2[0m
             [0;7;30;103mTRICE64_3  -1, -2, -3[0m
             [0;7;30;103mTRICE64_4  -1, -2, -3, -4[0m
             [0;7;30;103mTRICE64_5  -1, -2, -3, -4, -5[0m
             [0;7;30;103mTRICE64_6  -1, -2, -3, -4, -5, -6[0m
             [0;7;30;103mTRICE64_7  -1, -2, -3, -4, -5, -6, -7[0m
             [0;7;30;103mTRICE64_8  -1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;7;30;103mTRICE64_9  -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
             [0;7;30;103mTRICE64_10 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
             [0;7;30;103mTRICE64_11 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;7;30;103mTRICE64_12 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m       0_103[0m [0;7;30;103mTRICE64_1  -1[0m
[0;7;34;103m       0_109[0m [0;7;30;103mTRICE64_2  -1, -2[0m
[0;7;34;103m       0_114[0m [0;7;30;103mTRICE64_3  -1, -2, -3[0m
[0;7;34;103m       0_122[0m [0;7;30;103mTRICE64_4  -1, -2, -3, -4[0m
[0;7;34;103m       0_129[0m [0;7;30;103mTRICE64_5  -1, -2, -3, -4, -5[0m
[0;7;34;103m       0_136[0m [0;7;30;103mTRICE64_6  -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m       0_144[0m [0;7;30;103mTRICE64_7  -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m       0_152[0m [0;7;30;103mTRICE64_8  -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m       0_163[0m [0;7;30;103mTRICE64_9  -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m       0_172[0m [0;7;30;103mTRICE64_10 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m       0_195[0m [0;7;30;103mTRICE64_11 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m       0_204[0m [0;7;30;103mTRICE64_12 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRICE64_1  -1[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRICE64_2  -1, -2[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRICE64_3  -1, -2, -3[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRICE64_4  -1, -2, -3, -4[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRICE64_5  -1, -2, -3, -4, -5[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRICE64_6  -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRICE64_7  -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRICE64_8  -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRICE64_9  -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRICE64_10 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRICE64_11 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRICE64_12 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
             [0;7;38;5;118mtrice64 with 1 to 12 values (line 2136)[0m
             [0;7;30;103mtrice64 -1[0m
             [0;7;30;103mtrice64 -1, -2[0m
             [0;7;30;103mtrice64 -1, -2, -3[0m
             [0;7;30;103mtrice64 -1, -2, -3, -4[0m
             [0;7;30;103mtrice64 -1, -2, -3, -4, -5[0m
             [0;7;30;103mtrice64 -1, -2, -3, -4, -5, -6[0m
             [0;7;30;103mtrice64 -1, -2, -3, -4, -5, -6, -7[0m
             [0;7;30;103mtrice64 -1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;7;30;103mtrice64 -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
             [0;7;30;103mtrice64 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
             [0;7;30;103mtrice64 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;7;30;103mtrice64 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m       0_409[0m [0;7;30;103mTrice64 -1[0m
[0;7;34;103m       0_416[0m [0;7;30;103mTrice64 -1, -2[0m
[0;7;34;103m       0_423[0m [0;7;30;103mTrice64 -1, -2, -3[0m
[0;7;34;103m       0_431[0m [0;7;30;103mTrice64 -1, -2, -3, -4[0m
[0;7;34;103m       0_438[0m [0;7;30;103mTrice64 -1, -2, -3, -4, -5[0m
[0;7;34;103m       0_444[0m [0;7;30;103mTrice64 -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m       0_449[0m [0;7;30;103mTrice64 -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m       0_457[0m [0;7;30;103mTrice64 -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m       0_464[0m [0;7;30;103mTrice64 -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m       0_472[0m [0;7;30;103mTrice64 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m       0_480[0m [0;7;30;103mTrice64 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m       0_489[0m [0;7;30;103mTrice64 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRice64 -1[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRice64 -1, -2[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRice64 -1, -2, -3[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRice64 -1, -2, -3, -4[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRice64 -1, -2, -3, -4, -5[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRice64 -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRice64 -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRice64 -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRice64 -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRice64 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRice64 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRice64 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
             [0;7;38;5;118mtrice64_n with 1 to 12 values (line 2174)[0m
             [0;7;30;103mtrice64_1  -1[0m
             [0;7;30;103mtrice64_2  -1, -2[0m
             [0;7;30;103mtrice64_3  -1, -2, -3[0m
             [0;7;30;103mtrice64_4  -1, -2, -3, -4[0m
             [0;7;30;103mtrice64_5  -1, -2, -3, -4, -5[0m
             [0;7;30;103mtrice64_6  -1, -2, -3, -4, -5, -6[0m
             [0;7;30;103mtrice64_7  -1, -2, -3, -4, -5, -6, -7[0m
             [0;7;30;103mtrice64_8  -1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;7;30;103mtrice64_9  -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
             [0;7;30;103mtrice64_10 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
             [0;7;30;103mtrice64_11 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;7;30;103mtrice64_12 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m       0_693[0m [0;7;30;103mTrice64_1  -1[0m
[0;7;34;103m       0_700[0m [0;7;30;103mTrice64_2  -1, -2[0m
[0;7;34;103m       0_707[0m [0;7;30;103mTrice64_3  -1, -2, -3[0m
[0;7;34;103m       0_715[0m [0;7;30;103mTrice64_4  -1, -2, -3, -4[0m
[0;7;34;103m       0_722[0m [0;7;30;103mTrice64_5  -1, -2, -3, -4, -5[0m
[0;7;34;103m       0_730[0m [0;7;30;103mTrice64_6  -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m       0_738[0m [0;7;30;103mTrice64_7  -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m       0_746[0m [0;7;30;103mTrice64_8  -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m       0_754[0m [0;7;30;103mTrice64_9  -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m       0_762[0m [0;7;30;103mTrice64_10 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m       0_771[0m [0;7;30;103mTrice64_11 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m       0_777[0m [0;7;30;103mTrice64_12 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRice64_1  -1[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRice64_2  -1, -2[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRice64_3  -1, -2, -3[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRice64_4  -1, -2, -3, -4[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRice64_5  -1, -2, -3, -4, -5[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRice64_6  -1, -2, -3, -4, -5, -6[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRice64_7  -1, -2, -3, -4, -5, -6, -7[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRice64_8  -1, -2, -3, -4, -5, -6, -7, -8[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRice64_9  -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRice64_10 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRice64_11 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
[0;7;34;103m 0:00:00,011[0m [0;7;30;103mTRice32_12 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m       0_897[0m [0;7;38;5;118mColors and ticks[0m
[0;7;34;103m       0_897[0m --------------------------------------------------
[0;7;34;103m       0_897[0m --------------------------------------------------
[0;7;34;103m       0_897[0m [0;7;38;5;130m12345 as 16bit is 0011000000111001[0m
[0;7;34;103m       0_897[0m --------------------------------------------------
[0;7;34;103m       0_897[0m [0;7;38;5;118mThis ASSERT error is just a demo and no real error:[0m
[0;7;34;103m       0_897[0m --------------------------------------------------
[0;7;34;103m       0_897[0m [0;38;5;11;41mERR:error       message, SysTick is      0[0m
[0;7;34;103m       0_898[0m [0;7;38;5;11;41mWRN:warning     message, SysTick is      0[0m
[0;7;34;103m       0_898[0m [0;38;5;11;42mATT:attention   message, SysTick is      0[0m
[0;7;34;103m       0_898[0m [0;7;33;109mDIA:diagnostics message, SysTick is      0[0m
[0;7;34;103m       0_898[0m [0;7;34;103mTIM:timing      message, SysTick is      0[0m
[0;7;34;103m       0_898[0m [0;7;38;5;130mDBG:debug       message, SysTick is      0[0m
[0;7;34;103m       0_898[0m [0;7;38;5;118mSIG:signal      message, SysTick is      0[0m
[0;7;34;103m       0_898[0m [0;7;30;103mRD:read         message, SysTick is      0[0m
[0;7;34;103m       0_898[0m [0;4;30;103mWR:write        message, SysTick is      0[0m
[0;7;34;103m       0_898[0m [0;7;35;109mISR:interrupt   message, SysTick is      0[0m
[0;7;34;103m       0_898[0m [0;92;40mMSG:normal      message, SysTick is      0[0m
[0;7;34;103m       0_898[0m [0;1;36;109mINFO:informal   message, SysTick is      0[0m
[0;7;34;103m       0_898[0m [0;7;34;103mTRICE32_1  message, SysTick is      0[0m
[0;7;34;103m 0:00:00,012[0m [0;7;38;5;118mVarious ranges and formats[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8  %03x -> 001  07f  080  0ff[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8   %4d ->    1  127 -128   -1[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8   %4u ->    1  127  128  255[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8   %4o ->    1  177  200  377[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8   %4O ->  0o1 0o177 0o200 0o377[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8   %4X ->    1   7F   80   FF[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8   %4x ->    1   7f   80   ff[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8   %8b ->        1  1111111 10000000 11111111[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8  %08b -> 00000001 01111111 10000000 11111111[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE16  %05x ->   00001   07fff   08000   0ffff[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE16   %6d ->       1   32767  -32768      -1[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE16   %7o ->       1   77777  100000  177777[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE32 %09x ->      000000001      07fffffff       080000000     0ffffffff[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE32 %10d ->              1     2147483647     -2147483648      ffffffff[0m
[0;7;34;103m 0:00:00,012[0m [0;38;5;11;42mTRICE32         10101010101010101010101010101010[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE64 %09x ->      000000001      7fffffffffffffff       8000000000000000     ffffffffffffffff[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE64 %10d ->              1     9223372036854775807     -9223372036854775808    ffffffffffffffff[0m
[0;7;34;103m 0:00:00,012[0m [0;38;5;11;42mTRICE64       1010101010101010101010101010101010101010101010101010101010101010[0m
[0;7;34;103m 0:00:00,012[0m [0;7;38;5;118mLegacy TRICE8[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8_1 a1[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8_2 a1 a2[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8_3 a1 a2 a3[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8_4 a1 a2 a3 a4[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8_5 a1 a2 a3 a4 a5[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8_6 a1 a2 a3 a4 a5 a6[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8_7 a1 a2 a3 a4 a5 a6 a7[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8_8 A1 A2 A3 A4 a5 a6 a7 a8[0m
[0;7;34;103m       0_269[0m [0;93;40mTRICE8_1 -1[0m
[0;7;34;103m       0_270[0m [0;93;40mTRICE8_2 -1 -2[0m
[0;7;34;103m       0_270[0m [0;93;40mTRICE8_3 -1 -2 -3[0m
[0;7;34;103m       0_270[0m [0;93;40mTRICE8_4 -1 -2 -3 -4[0m
[0;7;34;103m       0_270[0m [0;93;40mTRICE8_5 -1 -2 -3 -4 -5[0m
[0;7;34;103m       0_270[0m [0;93;40mTRICE8_6 -1 -2 -3 -4 -5 -6[0m
[0;7;34;103m       0_270[0m [0;93;40mTRICE8_7 -1 -2 -3 -4 -5 -6 -7[0m
[0;7;34;103m       0_270[0m [0;93;40mTRICE8_8 -1 -2 -3 -4 -5 -6 -7 -8[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8_1 1[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8_2 1 2[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8_3 1 2 3[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8_4 1 2 3 4[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8_5 1 2 3 4 5[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8_6 1 2 3 4 5 6[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8_7 1 2 3 4 5 6 7[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8_8 1 2 3 4 5 6 7 8[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8_1 201[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8_2 201 202[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8_3 201 202 203[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8_4 201 202 203 204[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8_5 201 202 203 204 205[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8_6 201 202 203 204 205 206[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8_7 201 202 203 204 205 206 207[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8_8 201 202 203 204 205 206 207 208[0m
[0;7;34;103m 0:00:00,012[0m [0;93;40mTRICE8_1 %d=-127, %u=129, 0x%x=0x81, 0x%2x=0x81, 0x%02x=0x81, 0x%3x=0x 81, 0x%03x=0x081, %b=10000001[0m
[0;7;34;103m 0:00:00,012[0m [0;7;38;5;118mLegacy TRICE16-64[0m
[0;7;34;103m       0_466[0m [0;93;40mTRICE16_1 -111[0m
[0;7;34;103m       0_467[0m [0;93;40mTRICE16_2 -111 -222[0m
[0;7;34;103m       0_467[0m [0;93;40mTRICE16_3 -111 -222 -333[0m
[0;7;34;103m       0_467[0m [0;93;40mTRICE16_4 -111 -222 -333 -444[0m
[0;7;34;103m       0_494[0m [0;93;40mTRICE32_1 0123cafe[0m
[0;7;34;103m       0_494[0m [0;93;40mTRICE32_1 -111[0m
[0;7;34;103m       0_494[0m [0;93;40mTRICE32_2 ffffff91 ffffff22[0m
[0;7;34;103m       0_513[0m [0;93;40mTRICE32_2 -111 -222[0m
[0;7;34;103m       0_513[0m [0;93;40mTRICE32_3 ffffff91 ffffff22 fffffeb3[0m
[0;7;34;103m       0_513[0m [0;93;40mTRICE32_3 -111 -222 -333[0m
[0;7;34;103m       0_513[0m [0;93;40mTRICE32_4 ffffff91 ffffff22 fffffeb3 fffffe44[0m
[0;7;34;103m       0_513[0m [0;93;40mTRICE32_4 -111 -222 -333 -444[0m
[0;7;34;103m       0_572[0m [0;93;40mTRICE64_1 -111[0m
[0;7;34;103m       0_572[0m [0;93;40mTRICE64_2 -111 -222[0m
[0;7;34;103m       0_572[0m [0;93;40mTRICE16_1 60001[0m
[0;7;34;103m       0_572[0m [0;93;40mTRICE16_2 60001 60002[0m
[0;7;34;103m       0_572[0m [0;93;40mTRICE16_3 60001 60002 60003[0m
[0;7;34;103m       0_572[0m [0;93;40mTRICE16_4 60001 60002 60003 60004[0m
[0;7;34;103m       0_615[0m [0;93;40mTRICE32_1 4000000001[0m
[0;7;34;103m       0_615[0m [0;93;40mTRICE32_2 4000000001 4000000002[0m
[0;7;34;103m       0_615[0m [0;93;40mTRICE32_3 4000000001 4000000002 4000000003[0m
[0;7;34;103m       0_615[0m [0;93;40mTRICE32_4 4000000001 4000000002 4000000003 4000000004[0m
[0;7;34;103m       0_645[0m [0;93;40mTRICE64_1 ffffffffffffffff[0m
[0;7;34;103m       0_645[0m [0;93;40mTRICE64_2 ffffffffffffffff fffffffffffffffe[0m
[0;7;34;103m       0_645[0m [0;93;40mTRICE64_1 18446744073709551615[0m
[0;7;34;103m       0_645[0m [0;93;40mTRICE64_2 18446744073709551615 18446744073709551614[0m
             [0;7;38;5;118mcolored single letters and several TRICE macros in one line[0m
             [0;38;5;11;41mA[0m[0;7;38;5;11;41mB[0m[0;7;31;107mc[0m[0;4;30;103md[0m[0;7;30;103me[0m
             [0;7;33;109mf[0m[0;7;38;5;130mG[0m[0;93;40mH[0m[0;7;34;103mi[0m[0;92;40mJ[0m[0;7;38;5;130mk[0m
             1234[0;38;5;11;41m7[0m[0;92;40m12[0m[0;92;40m123[0m
             [0;38;5;11;41mA[0m[0;7;38;5;11;41mB[0m[0;7;31;107mc[0m[0;4;30;103md[0m[0;7;30;103me[0m
             [0;7;33;109mf[0m[0;7;38;5;118mTRICE8 with variable param count 1 to 12[0m
[0;7;34;103m       0_833[0m [0;93;40mTRICE8 -1[0m
[0;7;34;103m       0_833[0m [0;93;40mTRICE8 -1 -2[0m
[0;7;34;103m       0_833[0m [0;93;40mTRICE8 -1 -2 -3[0m
[0;7;34;103m       0_833[0m [0;93;40mTRICE8 -1 -2 -3 -4[0m
[0;7;34;103m       0_833[0m [0;93;40mTRICE8 -1 -2 -3 -4 -5[0m
[0;7;34;103m       0_833[0m [0;93;40mTRICE8 -1 -2 -3 -4 -5 -6[0m
[0;7;34;103m       0_833[0m [0;93;40mTRICE8 -1 -2 -3 -4 -5 -6 -7[0m
[0;7;34;103m       0_833[0m [0;93;40mTRICE8 -1 -2 -3 -4 -5 -6 -7 -8[0m
[0;7;34;103m       0_833[0m [0;93;40mTRICE8 -1 -2 -3 -4 -5 -6 -7 -8 -9[0m
[0;7;34;103m       0_833[0m [0;93;40mTRICE8 -1 -2 -3 -4 -5 -6 -7 -8 -9 -10[0m
[0;7;34;103m       0_833[0m [0;93;40mTRICE8 -1 -2 -3 -4 -5 -6 -7 -8 -9 -10 -11[0m
[0;7;34;103m       0_833[0m [0;93;40mTRICE8 -1 -2 -3 -4 -5 -6 -7 -8 -9 -10 -11 -12[0m
[0;7;34;103m       0_833[0m [0;93;40mTRICE8 true 11111101 fd FD -3 253 375 0o375 fd[0m
[0;7;34;103m       0_946[0m [0;93;40mTRICE8_1  -1[0m
[0;7;34;103m       0_946[0m [0;93;40mTRICE8_2  -1 -2[0m
[0;7;34;103m       0_946[0m [0;93;40mTRICE8_3  -1 -2 -3[0m
[0;7;34;103m       0_946[0m [0;93;40mTRICE8_4  -1 -2 -3 -4[0m
[0;7;34;103m       0_946[0m [0;93;40mTRICE8_5  -1 -2 -3 -4 -5[0m
[0;7;34;103m       0_964[0m [0;93;40mTRICE8_6  -1 -2 -3 -4 -5 -6[0m
[0;7;34;103m       0_964[0m [0;93;40mTRICE8_7  -1 -2 -3 -4 -5 -6 -7[0m
[0;7;34;103m       0_964[0m [0;93;40mTRICE8_8  -1 -2 -3 -4 -5 -6 -7 -8[0m
[0;7;34;103m       0_964[0m [0;93;40mTRICE8_9  -1 -2 -3 -4 -5 -6 -7 -8 -9[0m
[0;7;34;103m       0_964[0m [0;93;40mTRICE8_10 -1 -2 -3 -4 -5 -6 -7 -8 -9 -10[0m
[0;7;34;103m       0_965[0m [0;93;40mTRICE8_11 -1 -2 -3 -4 -5 -6 -7 -8 -9 -10 -11[0m
[0;7;34;103m       0_965[0m [0;93;40mTRICE8_12 -1 -2 -3 -4 -5 -6 -7 -8 -9 -10 -11 -12[0m
[0;7;34;103m       0_965[0m [0;93;40mTRICE8   true 11111101 fd FD -3 253 375 0o375 fd[0m
[0;7;34;103m       0_965[0m [0;93;40mTRICE8_9 true 11111101 fd FD -3 253 375 0o375 fd[0m
             [0;7;38;5;118mTRICE16 with variable param count 1 to 12[0m
[0;7;34;103m       0_081[0m [0;93;40mTRICE16 -1[0m
[0;7;34;103m       0_081[0m [0;93;40mTRICE16 -1 -2[0m
[0;7;34;103m       0_081[0m [0;93;40mTRICE16 -1 -2 -3[0m
[0;7;34;103m       0_081[0m [0;93;40mTRICE16 -1 -2 -3 -4[0m
[0;7;34;103m       0_081[0m [0;93;40mTRICE16 -1 -2 -3 -4 -5[0m
[0;7;34;103m       0_081[0m [0;93;40mTRICE16 -1 -2 -3 -4 -5 -6[0m
[0;7;34;103m       0_081[0m [0;93;40mTRICE16 -1 -2 -3 -4 -5 -6 -7[0m
[0;7;34;103m       0_081[0m [0;93;40mTRICE16 -1 -2 -3 -4 -5 -6 -7 -8[0m
[0;7;34;103m       0_082[0m [0;93;40mTRICE16 -1 -2 -3 -4 -5 -6 -7 -8 -9[0m
[0;7;34;103m       0_082[0m [0;93;40mTRICE16 -1 -2 -3 -4 -5 -6 -7 -8 -9 -10[0m
[0;7;34;103m       0_082[0m [0;93;40mTRICE16 -1 -2 -3 -4 -5 -6 -7 -8 -9 -10 -11[0m
[0;7;34;103m       0_082[0m [0;93;40mTRICE16 -1 -2 -3 -4 -5 -6 -7 -8 -9 -10 -11 -12[0m
[0;7;34;103m       0_082[0m [0;93;40mTRICE16 true 11 3 3 3 3 3 0o3 3[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE16_1  -1[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE16_2  -1 -2[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE16_3  -1 -2 -3[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE16_4  -1 -2 -3 -4[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE16_5  -1 -2 -3 -4 -5[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE16_6  -1 -2 -3 -4 -5 -6[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE16_7  -1 -2 -3 -4 -5 -6 -7[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE16_8  -1 -2 -3 -4 -5 -6 -7 -8[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE16_9  -1 -2 -3 -4 -5 -6 -7 -8 -9[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE16_10 -1 -2 -3 -4 -5 -6 -7 -8 -9 -10[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE16_11 -1 -2 -3 -4 -5 -6 -7 -8 -9 -10 -11[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE16_12 -1 -2 -3 -4 -5 -6 -7 -8 -9 -10 -11 -12[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE16 true 11 3 3 3 3 3 0o3 3[0m
             [0;7;38;5;118mTRICE32 with variable param count 1 to 12[0m
[0;7;34;103m       0_314[0m [0;93;40mTRICE32 -1[0m
[0;7;34;103m       0_314[0m [0;93;40mTRICE32 -1 -2[0m
[0;7;34;103m       0_314[0m [0;93;40mTRICE32 -1 -2 -3[0m
[0;7;34;103m       0_314[0m [0;93;40mTRICE32 -1 -2 -3 -4[0m
[0;7;34;103m       0_314[0m [0;93;40mTRICE32 -1 -2 -3 -4 -5[0m
[0;7;34;103m       0_314[0m [0;93;40mTRICE32 -1 -2 -3 -4 -5 -6[0m
[0;7;34;103m       0_314[0m [0;93;40mTRICE32 -1 -2 -3 -4 -5 -6 -7[0m
[0;7;34;103m       0_314[0m [0;93;40mTRICE32 -1 -2 -3 -4 -5 -6 -7 -8[0m
[0;7;34;103m       0_315[0m [0;93;40mTRICE32 -1 -2 -3 -4 -5 -6 -7 -8 -9[0m
[0;7;34;103m       0_315[0m [0;93;40mTRICE32 -1 -2 -3 -4 -5 -6 -7 -8 -9 -10[0m
[0;7;34;103m       0_315[0m [0;93;40mTRICE32 -1 -2 -3 -4 -5 -6 -7 -8 -9 -10 -11[0m
[0;7;34;103m       0_315[0m [0;93;40mTRICE32 -1 -2 -3 -4 -5 -6 -7 -8 -9 -10 -11 -12[0m
[0;7;34;103m       0_315[0m [0;93;40mTRICE32 true 11 3 3 3 3 3 0o3 3 3.141590e+00 3.141590 3.14159[0m
[0;7;34;103m       0_428[0m [0;93;40mTRICE32_1  -1[0m
[0;7;34;103m       0_428[0m [0;93;40mTRICE32_2  -1 -2[0m
[0;7;34;103m       0_428[0m [0;93;40mTRICE32_3  -1 -2 -3[0m
[0;7;34;103m       0_428[0m [0;93;40mTRICE32_4  -1 -2 -3 -4[0m
[0;7;34;103m       0_428[0m [0;93;40mTRICE32_5  -1 -2 -3 -4 -5[0m
[0;7;34;103m       0_428[0m [0;93;40mTRICE32_6  -1 -2 -3 -4 -5 -6[0m
[0;7;34;103m       0_428[0m [0;93;40mTRICE32_7  -1 -2 -3 -4 -5 -6 -7[0m
[0;7;34;103m       0_428[0m [0;93;40mTRICE32_8  -1 -2 -3 -4 -5 -6 -7 -8[0m
[0;7;34;103m       0_428[0m [0;93;40mTRICE32_9  -1 -2 -3 -4 -5 -6 -7 -8 -9[0m
[0;7;34;103m       0_429[0m [0;93;40mTRICE32_10 -1 -2 -3 -4 -5 -6 -7 -8 -9 -10[0m
[0;7;34;103m       0_429[0m [0;93;40mTRICE32_11 -1 -2 -3 -4 -5 -6 -7 -8 -9 -10 -11[0m
[0;7;34;103m       0_429[0m [0;93;40mTRICE32_12 -1 -2 -3 -4 -5 -6 -7 -8 -9 -10 -11 -12[0m
[0;7;34;103m       0_429[0m [0;93;40mTRICE32    true 11 3 3 3 3 3 0o3 3 3.141590e+00 3.141590 3.14159[0m
[0;7;34;103m       0_447[0m [0;93;40mTRICE32_12 true 11 3 3 3 3 3 0o3 3 3.141590e+00 3.141590 3.14159[0m
             [0;7;38;5;118mTRICE64 with variable param count 1 to 12[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE64 -1[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE64 -1 -2[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE64 -1 -2 -3[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE64 -1 -2 -3 -4[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE64 -1 -2 -3 -4 -5[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE64 -1 -2 -3 -4 -5 -6[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE64 -1 -2 -3 -4 -5 -6 -7[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE64 -1 -2 -3 -4 -5 -6 -7 -8[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE64 -1 -2 -3 -4 -5 -6 -7 -8 -9[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE64 -1 -2 -3 -4 -5 -6 -7 -8 -9 -10[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE64 -1 -2 -3 -4 -5 -6 -7 -8 -9 -10 -11[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE64 -1 -2 -3 -4 -5 -6 -7 -8 -9 -10 -11 -12[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE64 true 11 3 3 3 3 3 0o3 3 3.141590e+00 3.141590 3.14159[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE64_1  -1[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE64_2  -1 -2[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE64_3  -1 -2 -3[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE64_4  -1 -2 -3 -4[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE64_5  -1 -2 -3 -4 -5[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE64_6  -1 -2 -3 -4 -5 -6[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE64_7  -1 -2 -3 -4 -5 -6 -7[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE64_8  -1 -2 -3 -4 -5 -6 -7 -8[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE64_9  -1 -2 -3 -4 -5 -6 -7 -8 -9[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE64_10 -1 -2 -3 -4 -5 -6 -7 -8 -9 -10[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE64_11 -1 -2 -3 -4 -5 -6 -7 -8 -9 -10 -11[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE64_12 -1 -2 -3 -4 -5 -6 -7 -8 -9 -10 -11 -12[0m
[0;7;34;103m 0:00:00,013[0m [0;93;40mTRICE64_12 true 11 3 3 3 3 3 0o3 3 3.141590e+00 3.141590 3.14159[0m
             [0;38;5;11;42mpositive and negative float in format variants[0m
             [0;7;30;103mTRICE float 1089.608276 (%f)[0m
             [0;7;30;103mTRICE float 1089.608276 (%9f)[0m
             [0;7;30;103mTRICE float 1089.608276367 (%.9f)[0m
             [0;7;30;103mTRICE float      1090 (%9.f)[0m
             [0;7;30;103mTRICE float 1089.608276 (%9.6f)[0m
             [0;7;30;103mTRICE float -1089.608276 (%f)[0m
             [0;7;30;103mTRICE float -1089.608276 (%9f)[0m
             [0;7;30;103mTRICE float -1089.608276367 (%.9f)[0m
             [0;7;30;103mTRICE float     -1090 (%9.f)[0m
             [0;7;30;103mTRICE float -1089.608276 (%9.6f)[0m
             [0;7;30;103mTRICE float +1089.608276 (%f)[0m
             [0;7;30;103mTRICE float +1089.608276 (%9f)[0m
             [0;7;30;103mTRICE float +1089.608276367 (%.9f)[0m
             [0;7;30;103mTRICE float     +1090 (%9.f)[0m
             [0;7;30;103mTRICE float +1089.608276 (%9.6f)[0m
             [0;7;30;103mTRICE float -1089.608276 (%f)[0m
             [0;7;30;103mTRICE float -1089.608276 (%9f)[0m
             [0;7;30;103mTRICE float -1089.608276367 (%.9f)[0m
             [0;7;30;103mTRICE float     -1090 (%9.f)[0m
             [0;7;30;103mTRICE float -1089.608276 (%9.6f)[0m
             [0;7;30;103mTRICE float 1089.608276 (%f)[0m
             [0;7;30;103mTRICE float 1089.608276 (%9f)[0m
             [0;7;30;103mTRICE float 1089.608276367 (%.9f)[0m
             [0;7;30;103mTRICE float 1090      (%9.f)[0m
             [0;7;30;103mTRICE float 1089.608276 (%9.6f)[0m
             [0;7;30;103mTRICE float -1089.608276 (%f)[0m
             [0;7;30;103mTRICE float -1089.608276 (%9f)[0m
             [0;7;30;103mTRICE float -1089.608276367 (%.9f)[0m
             [0;7;30;103mTRICE float -1090     (%9.f)[0m
             [0;7;30;103mTRICE float -1089.608276 (%9.6f)[0m
             [0;38;5;11;42mpositive float & double in variants[0m
[0;7;34;103m 0:00:00,013[0m [0;7;30;103mTRICE32_1 float 1.089608e+03 (%e)[0m
[0;7;34;103m 0:00:00,013[0m [0;7;30;103mTRICE32_1 float 1089.608276 (%f)[0m
[0;7;34;103m 0:00:00,013[0m [0;7;30;103mTRICE32_1 float 1089.61 (%g)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE32_1 float 1.089608E+03 (%E)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE32_1 float 1089.608276 (%F)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE32_1 float 1089.61 (%G)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE32 float 1.089608e+03 (%e)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE32 float 1089.608276 (%f)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE32 float 1089.61 (%g)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE32 float 1.089608E+03 (%E)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE32 float 1089.608276 (%F)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE32 float 1089.61 (%G)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE float 1.089608e+03 (%e)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE float 1089.608276 (%f)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE float 1089.61 (%g)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE float 1.089608E+03 (%E)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE float 1089.608276 (%F)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE float 1089.61 (%G)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE64 double 5.180547e+02 (%e), aDouble(y)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE64 double 518.054749 (%f), aDouble(y)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE64 double 518.055 (%g), aDouble(y)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE64 double 5.180547E+02 (%E), aDouble(y)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE64 double 518.054749 (%F), aDouble(y)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE64 double 518.055 (%G), aDouble(y)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE64_1 double 5.180547e+02 (%e), aDouble(y)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE64_1 double 518.054749 (%f), aDouble(y)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE64_1 double 518.055 (%g), aDouble(y)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE64_1 double 5.180547E+02 (%E), aDouble(y)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE64_1 double 518.054749 (%F), aDouble(y)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE64_1 double 518.055 (%G), aDouble(y)[0m
             [0;38;5;11;42mnegative float & double[0m
             [0;7;30;103mTRICE float -1.089608e+03 (%e)[0m
             [0;7;30;103mTRICE float -1089.608276 (%f)[0m
             [0;7;30;103mTRICE float -1089.61 (%g)[0m
             [0;7;30;103mTRICE float -1.089608E+03 (%E)[0m
             [0;7;30;103mTRICE float -1089.608276 (%F)[0m
             [0;7;30;103mTRICE float -1089.61 (%G)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE64 double -5.180547e+02 (%e), aDouble(y)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE64 double -518.054749 (%f), aDouble(y)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE64 double -518.055 (%g), aDouble(y)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE64 double -5.180547E+02 (%E), aDouble(y)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE64 double -518.054749 (%F), aDouble(y)[0m
[0;7;34;103m 0:00:00,014[0m [0;7;30;103mTRICE64 double -518.055 (%G), aDouble(y)[0m
[0;7;34;103m 0:00:00,014[0m [0;38;5;11;42mformatted float[0m
[0;7;34;103m       0_284[0m [0;7;30;103mTRICE32 float 1.089608e+03 (%12.6e)[0m
[0;7;34;103m       0_284[0m [0;7;30;103mTRICE32 float  1089.608276 (%12.6f)[0m
[0;7;34;103m       0_284[0m [0;7;30;103mTRICE32 float      1089.61 (%12.6g)[0m
[0;7;34;103m       0_284[0m [0;7;30;103mTRICE32 float 1.089608E+03 (%12.6E)[0m
[0;7;34;103m       0_284[0m [0;7;30;103mTRICE32 float  1089.608276 (%12.6F)[0m
[0;7;34;103m       0_284[0m [0;7;30;103mTRICE32 float      1089.61 (%12.6G)[0m
[0;7;34;103m 0:00:00,014[0m [0;38;5;11;42mformatted double[0m
[0;7;34;103m       0_330[0m [0;7;30;103mTRICE64 double 5.180547e+02 (%12.6e), aDouble(y)[0m
[0;7;34;103m       0_330[0m [0;7;30;103mTRICE64 double   518.054749 (%12.6f), aDouble(y)[0m
[0;7;34;103m       0_330[0m [0;7;30;103mTRICE64 double      518.055 (%12.6g), aDouble(y)[0m
[0;7;34;103m       0_330[0m [0;7;30;103mTRICE64 double 5.180547E+02 (%12.6E), aDouble(y)[0m
[0;7;34;103m       0_330[0m [0;7;30;103mTRICE64 double   518.054749 (%12.6F), aDouble(y)[0m
[0;7;34;103m       0_330[0m [0;7;30;103mTRICE64 double      518.055 (%12.6G), aDouble(y)[0m
[0;7;34;103m 0:00:00,014[0m [0;38;5;11;42mVarious single arguments[0m
[0;7;34;103m       0_377[0m [0;7;30;103mTRICE8 line false (%t ,0)[0m
[0;7;34;103m       0_377[0m [0;7;30;103mTRICE8 line true (%t ,2)[0m
[0;7;34;103m       0_377[0m [0;7;30;103mTRICE8 line 255 (%u ,-1)[0m
[0;7;34;103m       0_377[0m [0;7;30;103mTRICE8 line 11111111 (%b ,-1)[0m
[0;7;34;103m       0_378[0m [0;7;30;103mTRICE8 line 377 (%o ,-1)[0m
[0;7;34;103m       0_378[0m [0;7;30;103mTRICE8 line 0o377 (%O ,-1)[0m
[0;7;34;103m       0_378[0m [0;7;30;103mTRICE8 line FF (%X ,-1)[0m
[0;7;34;103m       0_378[0m [0;7;30;103mTRICE8 line ff (%x ,-1)[0m
[0;7;34;103m       0_378[0m [0;7;30;103mTRICE8 line -1 (%d ,-1)[0m
[0;7;34;103m       0_450[0m [0;7;30;103mTRICE16_1 line false (%t ,0)[0m
[0;7;34;103m       0_451[0m [0;7;30;103mTRICE16_1 line true (%t ,2)[0m
[0;7;34;103m       0_451[0m [0;7;30;103mTRICE16_1 line 65535 (%u -1)[0m
[0;7;34;103m       0_451[0m [0;7;30;103mTRICE16_1 line 1111111111111111 (%b -1)[0m
[0;7;34;103m       0_451[0m [0;7;30;103mTRICE16_1 line 177777 (%o -1)[0m
[0;7;34;103m       0_451[0m [0;7;30;103mTRICE16_1 line ffff (%x -1)[0m
[0;7;34;103m       0_451[0m [0;7;30;103mTRICE16_1 line -1 (%d -1)[0m
[0;7;34;103m       0_451[0m [0;7;30;103mTrice line false (%t -1)[0m
[0;7;34;103m       0_451[0m [0;7;30;103mTrice line true (%t -1)[0m
[0;7;34;103m       0_451[0m [0;7;30;103mTrice line 4294967295 (%u)[0m
[0;7;34;103m       0_451[0m [0;7;30;103mTrice line 11111111111111111111111111111110 (%b)[0m
[0;7;34;103m       0_451[0m [0;7;30;103mTrice line 37777777775 (%o)[0m
[0;7;34;103m       0_451[0m [0;7;30;103mTrice line fffffffc (%x)[0m
[0;7;34;103m       0_451[0m [0;7;30;103mTrice line -5 (%d)[0m
             [0;92;40m[0m
             [0;92;40mA[0m
             [0;92;40mAA[0m
             [0;92;40mAAA[0m
             [0;92;40mAAAA[0m
             [0;92;40mAAAAA[0m
             [0;92;40mAAAAAA[0m
             [0;92;40mAAAAAAA[0m
             [0;92;40mAAAAAAAA[0m
             [0;92;40mAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA[0m
             [0;92;40m[0m
             [0;92;40mA[0m
             [0;92;40mAA[0m
             [0;92;40mAAA[0m
             [0;92;40mAAAA[0m
             [0;92;40mAAAAA[0m
             [0;92;40mAAAAAA[0m
             [0;92;40mAAAAAAA[0m
             [0;92;40mAAAAAAAA[0m
             [0;92;40mAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA[0m
             [0;92;40mAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA[0m
             [0;7;38;5;118mTRICE with 1 to 12 values[0m
             [0;7;30;103mTRICE -1[0m
             [0;7;30;103mTRICE -1, -2[0m
             [0;7;30;103mTRICE -1, -2, -3[0m
             [0;7;30;103mTRICE -1, -2, -3, -4[0m
             [0;7;30;103mTRICE -1, -2, -3, -4, -5[0m
             [0;7;30;103mTRICE -1, -2, -3, -4, -5, -6[0m
             [0;7;30;103mTRICE -1, -2, -3, -4, -5, -6, -7[0m
             [0;7;30;103mTRICE -1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;7;30;103mTRICE -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
             [0;7;30;103mTRICE -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
             [0;7;30;103mTRICE -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;7;30;103mTRICE -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
             [0;7;38;5;118mTRICE_n with 1 to 12 values[0m
             [0;7;30;103mTRICE_1  -1[0m
             [0;7;30;103mTRICE_2  -1, -2[0m
             [0;7;30;103mTRICE_3  -1, -2, -3[0m
             [0;7;30;103mTRICE_4  -1, -2, -3, -4[0m
             [0;7;30;103mTRICE_5  -1, -2, -3, -4, -5[0m
             [0;7;30;103mTRICE_6  -1, -2, -3, -4, -5, -6[0m
             [0;7;30;103mTRICE_7  -1, -2, -3, -4, -5, -6, -7[0m
             [0;7;30;103mTRICE_8  -1, -2, -3, -4, -5, -6, -7, -8[0m
             [0;7;30;103mTRICE_9  -1, -2, -3, -4, -5, -6, -7, -8, -9[0m
             [0;7;30;103mTRICE_10 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10[0m
             [0;7;30;103mTRICE_11 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11[0m
             [0;7;30;103mTRICE_12 -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12[0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;118mTrice16 with 1 to 12 pointer[0m
[0;7;34;103m       0_088[0m [0;7;30;103mTrice16 ffff[0m
[0;7;34;103m       0_088[0m [0;7;30;103mTrice16 ffff, fffe[0m
[0;7;34;103m       0_089[0m [0;7;30;103mTrice16 ffff, fffe, fffd[0m
[0;7;34;103m       0_089[0m [0;7;30;103mTrice16 ffff, fffe, fffd, fffc[0m
[0;7;34;103m       0_089[0m [0;7;30;103mTrice16 ffff, fffe, fffd, fffc, fffb[0m
[0;7;34;103m       0_089[0m [0;7;30;103mTrice16 ffff, fffe, fffd, fffc, fffb, fffa[0m
[0;7;34;103m       0_089[0m [0;7;30;103mTrice16 ffff, fffe, fffd, fffc, fffb, fffa, fff9[0m
[0;7;34;103m       0_089[0m [0;7;30;103mTrice16 ffff, fffe, fffd, fffc, fffb, fffa, fff9, fff8[0m
[0;7;34;103m       0_089[0m [0;7;30;103mTrice16 ffff, fffe, fffd, fffc, fffb, fffa, fff9, fff8, fff7[0m
[0;7;34;103m       0_089[0m [0;7;30;103mTrice16 ffff, fffe, fffd, fffc, fffb, fffa, fff9, fff8, fff7, fff6[0m
[0;7;34;103m       0_089[0m [0;7;30;103mTrice16 ffff, fffe, fffd, fffc, fffb, fffa, fff9, fff8, fff7, fff6, fff5[0m
[0;7;34;103m       0_089[0m [0;7;30;103mTrice16 ffff, fffe, fffd, fffc, fffb, fffa, fff9, fff8, fff7, fff6, fff5, fff4[0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;118mTRICE16 with 1 to 12 hex[0m
[0;7;34;103m       0_177[0m [0;7;30;103mTrice16 FFFF[0m
[0;7;34;103m       0_177[0m [0;7;30;103mTrice16 FFFF, FFFE[0m
[0;7;34;103m       0_177[0m [0;7;30;103mTrice16 FFFF, FFFE, FFFD[0m
[0;7;34;103m       0_177[0m [0;7;30;103mTrice16 FFFF, FFFE, FFFD, FFFC[0m
[0;7;34;103m       0_177[0m [0;7;30;103mTrice16 FFFF, FFFE, FFFD, FFFC, FFFB[0m
[0;7;34;103m       0_177[0m [0;7;30;103mTrice16 FFFF, FFFE, FFFD, FFFC, FFFB, FFFA[0m
[0;7;34;103m       0_177[0m [0;7;30;103mTrice16 FFFF, FFFE, FFFD, FFFC, FFFB, FFFA, FFF9[0m
[0;7;34;103m       0_177[0m [0;7;30;103mTrice16 FFFF, FFFE, FFFD, FFFC, FFFB, FFFA, FFF9, FFF8[0m
[0;7;34;103m       0_177[0m [0;7;30;103mTrice16 FFFF, FFFE, FFFD, FFFC, FFFB, FFFA, FFF9, FFF8, FFF7[0m
[0;7;34;103m       0_177[0m [0;7;30;103mTrice16 FFFF, FFFE, FFFD, FFFC, FFFB, FFFA, FFF9, FFF8, FFF7, FFF6[0m
[0;7;34;103m       0_178[0m [0;7;30;103mTrice16 FFFF, FFFE, FFFD, FFFC, FFFB, FFFA, FFF9, FFF8, FFF7, FFF6, FFF5[0m
[0;7;34;103m       0_178[0m [0;7;30;103mTrice16 FFFF, FFFE, FFFD, FFFC, FFFB, FFFA, FFF9, FFF8, FFF7, FFF6, FFF5, FFF4[0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
             [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m       0_274[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
             [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m       0_293[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
             [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m       0_318[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
             [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m       0_343[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
             [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m       0_367[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
             [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m       0_385[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
             [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m       0_408[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
             [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m       0_426[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
             [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m       0_450[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
             [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m       0_469[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
             [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m       0_493[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
             [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m       0_512[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
             [0;7;38;5;11;41m Hello! 👋🙂 [0m
             [0;7;38;5;11;41m Hello! 👋🙂 [0m
             [0;7;38;5;11;41m Hello! 👋🙂 [0m
             [0;7;38;5;11;41m Hello! 👋🙂 [0m
             [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m       0_550[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
             [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m       0_573[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
             [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m       0_591[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
             [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m       0_616[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
             [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m       0_634[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
             [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m       0_659[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
             [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m       0_678[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
             [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m       0_696[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
             [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m       0_715[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
             [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m       0_740[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
             [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m       0_759[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m
[0;7;34;103m 0:00:00,015[0m [0;7;38;5;11;41m Hello! 👋🙂 [0m

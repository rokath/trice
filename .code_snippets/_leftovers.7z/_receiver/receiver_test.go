package receiver

import (
	"testing"
)

// Test is just to have a test
func TestDummy(t *testing.T) {
}

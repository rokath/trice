// Copyright 2020 Thomas.Hoehenleitner [at] seerose.net
// Use of this source code is governed by a license that can be found in the LICENSE file.

package display

// io
// type StringWriter interface {
//    WriteString(s string) (n int, err error)
//}
